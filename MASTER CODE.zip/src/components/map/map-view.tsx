
'use client';

import Map, { Marker, Popup, NavigationControl, FullscreenControl, Source, Layer } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';
import type { LineLayer } from 'maplibre-gl';

import type { Incident, Responder, Hospital, Location } from '@/lib/types';
import { useState } from 'react';
import type { MapLayerMouseEvent } from 'maplibre-gl';
import { Icons } from '../icons';

interface MapViewProps {
  incidents: Incident[];
  responders: Responder[];
  hospitals: Hospital[];
  selectedIncident: Incident | null;
  assignedResponder?: Responder;
  onMapClick: (location: Location) => void;
  routesGeoJSON: any[];
  etas: {[key: string]: string};
}

const incidentStatusColors = {
  New: 'red',
  'In Progress': 'orange',
  Resolved: 'green',
};

const responderTypeColors: { [key: string]: string } = {
    'Type A (Basic)': '#A855F7',      // purple-500
    'Type B (BLS)': '#EC4899',        // pink-500
    'Type C (ALS)': '#F59E0B',        // amber-500
    'Type D (ICU)': '#84CC16',        // lime-500
    'Type E (Neonatal)': '#10B981',   // emerald-500
    'Type F (Disaster)': '#FBBF24',   // amber-400
    'Air Ambulance': '#0EA5E9',       // sky-500
    'Fire Engine': '#EF4444',         // red-500
    'Police Car': '#3B82F6',          // blue-500
};


const hospitalColor = '#60A5FA'; // blue-400

const routeLayer: LineLayer = {
  id: 'route-layer',
  type: 'line',
  source: 'route-source',
  layout: {
    'line-join': 'round',
    'line-cap': 'round',
  },
  paint: {
    'line-color': '#16A34A', // green-600
    'line-width': 6,
    'line-opacity': 0.85,
  },
};

export default function MapView({ incidents, responders, hospitals, selectedIncident, assignedResponder, onMapClick, routesGeoJSON, etas }: MapViewProps) {
  const [popupInfo, setPopupInfo] = useState<any>(null);

  const center = selectedIncident
    ? { longitude: selectedIncident.location.lng, latitude: selectedIncident.location.lat }
    : { longitude: 77.5946, latitude: 12.9716 }; // Default to Bengaluru

  
  const handleMapClick = (event: MapLayerMouseEvent) => {
    onMapClick({ lat: event.lngLat.lat, lng: event.lngLat.lng });
  };
  
  const geojson = {
    type: 'FeatureCollection',
    features: routesGeoJSON.map(routeCoords => ({
      type: 'Feature',
      geometry: {
        type: 'LineString',
        coordinates: routeCoords,
      },
      properties: {},
    })),
  };

  const getResponderIcon = (responder: Responder) => {
      let color = responderTypeColors[responder.type] || '#64748B'; // Default to slate if type not found
      let IconComponent = Icons.ambulance;

      if (responder.type === 'Fire Engine') {
          IconComponent = Icons.fireTruck;
      } else if (responder.type === 'Police Car') {
          IconComponent = Icons.policeCar;
      }

      const iconProps = {
          style: {
              width: '1.5rem',
              height: '1.5rem',
              color: 'white',
              backgroundColor: color,
              borderRadius: '50%',
              padding: '4px',
              border: '2px solid white',
              boxShadow: '0 0 5px rgba(0,0,0,0.5)',
          }
      };
      
      return <IconComponent {...iconProps} />;
  };

  return (
    <Map
      initialViewState={{
        ...center,
        zoom: 11,
      }}
      style={{ width: '100%', height: '100%' }}
      mapStyle="https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json"
      attributionControl={true}
      onClick={handleMapClick}
      cursor="crosshair"
    >
      <FullscreenControl />
      <NavigationControl />

      <Source id="route-source" type="geojson" data={geojson}>
        <Layer {...routeLayer} />
      </Source>

      {incidents.map(incident => (
        <Marker
          key={`incident-${incident.id}`}
          longitude={incident.location.lng}
          latitude={incident.location.lat}
          anchor="bottom"
          onClick={e => {
            e.originalEvent.stopPropagation();
            setPopupInfo({ ...incident, longitude: incident.location.lng, latitude: incident.location.lat });
          }}
        >
          <div className="w-6 h-10" style={{ transform: 'translate(-50%, -100%)' }}>
            <svg viewBox="0 0 24 24" fill={incidentStatusColors[incident.status]} xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
            </svg>
          </div>
        </Marker>
      ))}

      {responders.map(responder => (
        <Marker
          key={`responder-${responder.id}`}
          longitude={responder.lng}
          latitude={responder.lat}
          anchor="center"
           onClick={e => {
            e.originalEvent.stopPropagation();
            setPopupInfo({ ...responder, longitude: responder.lng, latitude: responder.lat });
          }}
        >
            <>
                {getResponderIcon(responder)}
                {etas[responder.id] && responder.status !== 'Available' && (
                   <div className="eta-label">
                     {etas[responder.id]}
                   </div>
                )}
            </>
        </Marker>
      ))}

      {hospitals.map(hospital => (
        <Marker
          key={`hospital-${hospital.name}`}
          longitude={hospital.location.lng}
          latitude={hospital.location.lat}
          anchor="center"
          onClick={e => {
            e.originalEvent.stopPropagation();
            setPopupInfo({ ...hospital, longitude: hospital.location.lng, latitude: hospital.location.lat });
          }}
        >
          <div
            style={{
              backgroundColor: hospitalColor,
              width: '1.5rem',
              height: '1.5rem',
              borderRadius: '50%',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              border: '2px solid white',
              boxShadow: '0 0 5px rgba(0,0,0,0.5)',
              color: 'white',
              fontWeight: 'bold',
              fontSize: '14px',
            }}
          >
            H
          </div>
        </Marker>
      ))}

      {popupInfo && (
        <Popup
          anchor="top"
          longitude={popupInfo.longitude}
          latitude={popupInfo.latitude}
          onClose={() => setPopupInfo(null)}
          closeOnClick={false}
          offset={25}
        >
            <div className="text-sm p-1">
                {popupInfo.type && <b>{popupInfo.type} ({popupInfo.status})</b>}
                {popupInfo.name && <b>{popupInfo.name}</b>}
                <br />
                {popupInfo.description && <span>{popupInfo.description}</span>}
                {popupInfo.beds && <span>Beds: {popupInfo.beds}</span>}
                {popupInfo.capabilities && <p className="text-xs mt-1">Capabilities: {popupInfo.capabilities.join(', ')}</p>}
            </div>
        </Popup>
      )}
    </Map>
  );
}
