
'use client';

import { useEffect } from 'react';
import { useMap } from 'react-map-gl/maplibre';
import type { Location } from '@/lib/types';
import type { LineLayer } from 'maplibre-gl';

interface MapRouteProps {
  start: Location;
  end: Location;
}

const routeLayer: LineLayer = {
  id: 'route',
  type: 'line',
  source: 'route',
  layout: {
    'line-join': 'round',
    'line-cap': 'round',
  },
  paint: {
    'line-color': '#3B82F6',
    'line-width': 6,
    'line-opacity': 0.8,
  },
};

export default function MapRoute({ start, end }: MapRouteProps) {
  const { current: map } = useMap();

  useEffect(() => {
    if (!map) return;

    const fetchRoute = async () => {
      const url = `https://router.project-osrm.org/route/v1/driving/${start.lng},${start.lat};${end.lng},${end.lat}?geometries=geojson`;

      try {
        const response = await fetch(url);
        const data = await response.json();
        if (data.routes && data.routes.length > 0) {
          const route = data.routes[0].geometry;
          
          if (map.getSource('route')) {
             (map.getSource('route') as any).setData({
                type: 'Feature',
                properties: {},
                geometry: route,
             });
          } else {
            map.addSource('route', {
              type: 'geojson',
              data: {
                type: 'Feature',
                properties: {},
                geometry: route,
              },
            });
            map.addLayer(routeLayer);
          }
        }
      } catch (error) {
        console.error('Error fetching route:', error);
      }
    };

    if (start && end) {
      fetchRoute();
    }
    
    return () => {
      if (map.getLayer('route')) {
        map.removeLayer('route');
      }
      if (map.getSource('route')) {
        map.removeSource('route');
      }
    }
  }, [map, start, end]);

  return null;
}
