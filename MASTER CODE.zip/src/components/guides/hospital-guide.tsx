import type { Hospital } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Badge } from "../ui/badge";
import { cn } from "@/lib/utils";

interface HospitalGuideProps {
    hospitals: Hospital[];
    onBack: () => void;
}

const bedStatusStyles: Record<Hospital['beds'], string> = {
    Low: "bg-[hsl(var(--status-high)/0.1)] text-[hsl(var(--status-high))] border-[hsl(var(--status-high)/0.2)]",
    Medium: "bg-[hsl(var(--status-medium)/0.1)] text-[hsl(var(--status-medium))] border-[hsl(var(--status-medium)/0.2)]",
    High: "bg-[hsl(var(--status-low)/0.1)] text-[hsl(var(--status-low))] border-[hsl(var(--status-low)/0.2)]",
};

export default function HospitalGuide({ hospitals, onBack }: HospitalGuideProps) {
    return (
        <div className="flex flex-col h-full p-4 space-y-4">
            <div className="flex-shrink-0 flex items-center gap-4">
                 <Button variant="outline" size="icon" onClick={onBack}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <div>
                    <h1 className="text-2xl font-bold">Hospital Guide</h1>
                    <p className="text-sm text-muted-foreground">Reference for all available medical facilities.</p>
                </div>
            </div>
            <div className="flex-grow grid grid-cols-1 gap-4 overflow-y-auto">
                {hospitals.map(hospital => (
                    <Card key={hospital.name}>
                        <CardHeader className="pb-2">
                            <CardTitle className="flex justify-between items-start text-lg">
                                <span>{hospital.name}</span>
                                <Badge variant="outline" className={cn("capitalize", bedStatusStyles[hospital.beds])}>
                                    {hospital.beds} Beds
                                </Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="text-sm space-y-2 text-muted-foreground">
                            <p><strong className="text-foreground">Address:</strong> {hospital.address}</p>
                            <p><strong className="text-foreground">Phone:</strong> {hospital.phone}</p>
                            <div>
                                <strong className="text-foreground">Capabilities:</strong> 
                                <div className="flex flex-wrap gap-1 mt-1">
                                    {hospital.capabilities.map(cap => (
                                        <Badge key={cap} variant="secondary">{cap}</Badge>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
