import type { FleetDescription } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import Image from "next/image";
import placeholderImages from "@/lib/placeholder-images.json";

interface FleetGuideProps {
    fleetDescriptions: FleetDescription[];
    onBack: () => void;
}

type PlaceholderImages = {
    [key: string]: {
        url: string;
        hint: string;
    }
}

export default function FleetGuide({ fleetDescriptions, onBack }: FleetGuideProps) {
    const images = placeholderImages as PlaceholderImages;

    return (
        <div className="flex flex-col h-full">
            <div className="flex-shrink-0 flex items-center gap-4">
                 <Button variant="outline" size="icon" onClick={onBack}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <div>
                    <h1 className="text-2xl font-bold">Fleet Guide</h1>
                    <p className="text-sm text-muted-foreground">Reference for all available unit types.</p>
                </div>
            </div>
            <div className="flex-grow grid grid-cols-1 gap-4 overflow-y-auto pt-4">
                {fleetDescriptions.map(unit => {
                    const imageData = images[unit.imageKey];
                    return (
                        <Card key={unit.name}>
                            <CardHeader>
                                {imageData && (
                                    <Image 
                                        src={imageData.url}
                                        alt={unit.name} 
                                        width={600} 
                                        height={400} 
                                        className="w-full h-32 object-cover rounded-md mb-3"
                                        data-ai-hint={imageData.hint}
                                    />
                                )}
                                <CardTitle>{unit.name}</CardTitle>
                            </CardHeader>
                            <CardContent className="text-sm space-y-2">
                                <p><strong>Purpose:</strong> {unit.purpose}</p>
                                <p><strong>Staff:</strong> {unit.staff}</p>
                                <p><strong>Equipment:</strong> {unit.equipment}</p>
                            </CardContent>
                        </Card>
                    );
                })}
            </div>
        </div>
    );
}

    