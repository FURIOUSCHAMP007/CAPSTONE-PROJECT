import type { IncidentType } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Badge } from "../ui/badge";

interface IncidentGuideProps {
    incidentTypes: IncidentType[];
    onBack: () => void;
}

const severityColors: {[key: string]: string} = {
    'Critical': 'bg-red-500/20 text-red-700 border-red-500/30',
    'High': 'bg-orange-500/20 text-orange-700 border-orange-500/30',
    'Medium': 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30',
    'Low': 'bg-blue-500/20 text-blue-700 border-blue-500/30'
}


export default function IncidentGuide({ incidentTypes, onBack }: IncidentGuideProps) {

    return (
        <div className="flex flex-col h-full">
            <div className="flex-shrink-0 flex items-center gap-4">
                 <Button variant="outline" size="icon" onClick={onBack}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <div>
                    <h1 className="text-2xl font-bold">Incident Guide</h1>
                    <p className="text-sm text-muted-foreground">Reference manual for all incident types.</p>
                </div>
            </div>
            <div className="flex-grow grid grid-cols-1 gap-4 overflow-y-auto pt-4">
                {incidentTypes.map(incident => (
                    <Card key={incident.name}>
                        <CardHeader>
                             <CardTitle className="flex justify-between items-start">
                                <span>{incident.name}</span>
                                <Badge variant="outline" className={severityColors[incident.severity]}>
                                    {incident.severity}
                                </Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="text-sm space-y-2">
                            <p><strong>Description:</strong> {incident.description}</p>
                            <p><strong>Recommended Unit:</strong> {incident.recommendedUnit}</p>
                             {incident.type === 'Disaster' && (
                                <Badge variant="destructive">Disaster Protocol</Badge>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
