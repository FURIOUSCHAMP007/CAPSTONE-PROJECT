import type { LucideProps } from 'lucide-react';
import { Flame, Hospital, Shield, Siren, Truck, Bot, List, MapPin } from 'lucide-react';

export const Icons = {
  medical: (props: LucideProps) => <Siren {...props} />,
  fire: (props: LucideProps) => <Flame {...props} />,
  crime: (props: LucideProps) => <Shield {...props} />,
  ambulance: (props: LucideProps) => <Truck {...props} />,
  fireTruck: (props: LucideProps) => <Flame {...props} />,
  policeCar: (props: LucideProps) => <Shield {...props} />,
  hospital: (props: LucideProps) => <Hospital {...props} />,
  ai: (props: LucideProps) => <Bot {...props} />,
  list: (props: LucideProps) => <List {...props} />,
  mapPin: (props: LucideProps) => <MapPin {...props} />,
};
