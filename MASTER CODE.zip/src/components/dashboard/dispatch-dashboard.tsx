
'use client';

import { useState, useTransition } from 'react';
import type { Incident, Responder, Hospital, LogEntry, Location } from '@/lib/types';
import { initialResponders, initialHospitals, fleetDescriptions, incidentTypes } from '@/lib/data';
import { getDistance } from 'geolib';

import NewIncidentForm from './new-incident-form';
import FleetStatus from './fleet-status';
import SystemLog from './system-log';
import IncidentSummary from './incident-summary';
import FleetGuide from '../guides/fleet-guide';
import HospitalGuide from '../guides/hospital-guide';
import IncidentGuide from '../guides/incident-guide';
import AnalyticsDashboard from './analytics-dashboard';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { BookOpen, Hospital as HospitalIcon, Siren, TrafficCone, X, LineChart, ShieldAlert } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ThemeToggle } from '@/components/theme-toggle';
import { getTrafficReport, type GetTrafficReportOutput } from '@/ai/flows/get-traffic-report';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

/**
 * Props for the main DispatchDashboard component.
 * This component acts as the central control panel for the application.
 */
interface ControlPanelProps {
  incidents: Incident[];
  setIncidents: React.Dispatch<React.SetStateAction<Incident[]>>;
  selectedIncident: Incident | null;
  setSelectedIncident: React.Dispatch<React.SetStateAction<Incident | null>>;
  responders: Responder[];
  setResponders: React.Dispatch<React.SetStateAction<Responder[]>>;
  hospitals: Hospital[];
  clickedLocation: Location | null;
  setClickedLocation: React.Dispatch<React.SetStateAction<Location | null>>;
  updateRoute: (responderId: string, waypoints: Location[]) => void;
  addLog: (message: string, level: LogEntry['level'], incidentId?: string) => void;
  logs: LogEntry[];
}

export default function DispatchDashboard({ 
  incidents, setIncidents, selectedIncident, setSelectedIncident, 
  responders, setResponders, hospitals, clickedLocation, setClickedLocation,
  updateRoute, addLog, logs
}: ControlPanelProps) {
  // State to manage which view is currently displayed in the dashboard (e.g., main dispatch, guides, analytics).
  const [view, setView] = useState<'dispatch' | 'fleet' | 'hospital' | 'incident' | 'analytics'>('dispatch');
  // State for handling the loading status of the AI traffic report.
  const [isTrafficPending, startTrafficTransition] = useTransition();
  // State to store the fetched traffic report data.
  const [trafficReport, setTrafficReport] = useState<GetTrafficReportOutput | null>(null);
  // State to store any errors from the traffic report fetch.
  const [trafficError, setTrafficError] = useState<string | null>(null);

  /**
   * Finds the closest responder from a given list to a specific location.
   * @param responderList - The list of responders to search through.
   * @param location - The target location.
   * @returns The responder object that is closest to the location.
   */
  const findClosestResponder = (responderList: Responder[], location: Location): Responder => {
    let closestResponder = responderList[0];
    let minDistance = Infinity;

    responderList.forEach(responder => {
      const distance = getDistance(
        { latitude: location.lat, longitude: location.lng },
        { latitude: responder.lat, longitude: responder.lng }
      );
      if (distance < minDistance) {
        minDistance = distance;
        closestResponder = responder;
      }
    });
    return closestResponder;
  }
  
  /**
   * Finds a suitable unit for dispatch based on availability and proximity.
   * Prioritizes units of the required type, but falls back to any available unit if none are found.
   * @param incidentLocation - The location of the incident.
   * @param requiredUnitType - The preferred type of responder unit.
   * @returns The best available responder, or null if no units are available.
   */
  const findUnitForDispatch = (incidentLocation: Location, requiredUnitType: string): Responder | null => {
     const availableResponders = responders.filter(r => r.status === 'Available' && r.type === requiredUnitType);
     if (availableResponders.length === 0) {
        // Fallback: if no units of the required type are available, find the closest of any type.
        const anyAvailable = responders.filter(r => r.status === 'Available');
        if (anyAvailable.length === 0) return null;
        return findClosestResponder(anyAvailable, incidentLocation);
     }
     return findClosestResponder(availableResponders, incidentLocation);
  }

 /**
 * Creates a new incident, assigns units, and updates the application state.
 * This is the core function for initiating a dispatch.
 * @param incidentData - The basic data for the new incident.
 * @param requiredUnits - An array of required unit types and quantities, determined by AI or pre-defined packages.
 * @returns A promise that resolves to the newly created incident object.
 */
 const createNewIncident = async (incidentData: Omit<Incident, 'id' | 'timestamp' | 'status'>, requiredUnits?: { unitType: string, quantity: number }[]): Promise<Incident> => {
    const newIncident: Incident = {
      ...incidentData,
      id: `INC-${Date.now()}`,
      timestamp: new Date().toISOString(),
      status: 'New',
    };

    if (!requiredUnits) {
        addLog(`No required units specified for incident ${newIncident.id}`, 'error', newIncident.id);
        setIncidents(prev => [...prev, newIncident]);
        return newIncident;
    }

    let assignedUnitIds: string[] = [];
    // Create a mutable copy of responders to track assignments within this dispatch operation.
    let tempResponders = [...responders];

    // Safety Protocol: Always dispatch a police car for scene safety if not already included.
    if (!requiredUnits.some(p => p.unitType === 'Police Car')) {
        requiredUnits.push({ unitType: 'Police Car', quantity: 1 });
        addLog(`Adding 1 Police Car to dispatch for scene safety.`, 'dispatch', newIncident.id);
    }

    // Iterate through the package to find and assign units.
    requiredUnits.forEach(pkg => {
        for (let i = 0; i < pkg.quantity; i++) {
            // Find available units that match the type and have not already been assigned.
            const available = tempResponders.filter(r => r.status === 'Available' && r.type === pkg.unitType && !assignedUnitIds.includes(r.id));
            
            if (available.length > 0) {
                const unitToAssign = findClosestResponder(available, newIncident.location);
                assignedUnitIds.push(unitToAssign.id);

                // Update the temporary responder state.
                tempResponders = tempResponders.map(r => 
                    r.id === unitToAssign.id 
                    ? { ...r, status: 'Enroute to Incident', incidentId: newIncident.id, routeIndex: 0 } 
                    : r
                );
                addLog(`Unit ${unitToAssign.id} (${unitToAssign.type}) assigned to incident ${newIncident.id}.`, 'dispatch', newIncident.id);
            } else {
                addLog(`Could not find an available unit of type "${pkg.unitType}" for dispatch.`, 'error', newIncident.id);
            }
        }
    });

    if (assignedUnitIds.length > 0) {
        newIncident.unitId = assignedUnitIds.join(', ');
        newIncident.status = 'In Progress';
    } else {
        addLog(`No available units to assign to incident ${newIncident.id}.`, 'error', newIncident.id);
    }
    
    // Commit the changes to the main application state.
    setResponders(tempResponders);
    
    // Defer route updates until after state has been set to ensure responder data is current.
    setTimeout(() => {
      assignedUnitIds.forEach(id => {
        const responder = tempResponders.find(r => r.id === id);
        if (responder) {
          updateRoute(responder.id, [responder, newIncident.location]);
        }
      });
    }, 0);

    setIncidents(prev => [...prev, newIncident]);
    setSelectedIncident(newIncident);
    setClickedLocation(null);
    addLog(`New Incident ${newIncident.id} created for ${newIncident.type}.`, 'dispatch', newIncident.id);
    return newIncident;
};

  /**
   * Marks an incident as resolved and updates its status in the application state.
   * @param incidentId - The ID of the incident to resolve.
   */
  const handleResolveIncident = (incidentId: string) => {
    setIncidents(prev => 
      prev.map(i => i.id === incidentId ? { ...i, status: 'Resolved' } : i)
    );
    // Also update the selected incident if it's the one being resolved.
    if (selectedIncident && selectedIncident.id === incidentId) {
      setSelectedIncident(prev => prev ? { ...prev, status: 'Resolved' } : null);
    }
    addLog(`Incident ${incidentId} has been marked as resolved.`, 'success', incidentId);
  };
  
  /**
   * Fetches a live traffic report using an AI flow and updates the UI.
   */
  const handleGetTrafficReport = () => {
    startTrafficTransition(async () => {
      setTrafficReport(null);
      setTrafficError(null);
      addLog('Fetching live traffic report...', 'ai');
      try {
        const result = await getTrafficReport();
        setTrafficReport(result);
        addLog('Traffic report received.', 'ai');
      } catch (e) {
        addLog('Failed to fetch traffic report.', 'error');
        setTrafficError('Failed to fetch traffic report. Please try again.');
      }
    });
  };
  
  /**
   * Renders the currently active view based on the `view` state.
   * @returns The JSX for the current view.
   */
  const renderView = () => {
    switch (view) {
      case 'fleet':
        return <FleetGuide fleetDescriptions={fleetDescriptions} onBack={() => setView('dispatch')} />;
      case 'hospital':
        return <HospitalGuide hospitals={hospitals} onBack={() => setView('dispatch')} />;
      case 'incident':
        return <IncidentGuide incidentTypes={incidentTypes} onBack={() => setView('dispatch')} />;
      case 'analytics':
        return <AnalyticsDashboard incidents={incidents} responders={responders} onBack={() => setView('dispatch')} />;
      default:
        // The main dispatch view.
        return (
          <div className="flex-grow flex flex-col space-y-4 pt-4 overflow-y-auto">
            <div className="px-1 space-y-2">
              {/* Display loading/error/success states for traffic report */}
              {isTrafficPending && <Skeleton className="h-16 w-full" />}
              {trafficError && (
                <Alert variant="destructive">
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{trafficError}</AlertDescription>
                </Alert>
              )}
              {trafficReport && (
                 <Alert>
                  <TrafficCone className="h-4 w-4" />
                   <AlertTitle className="flex justify-between items-center">
                     Live Traffic Update
                     <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setTrafficReport(null)}><X className="h-3 w-3"/></Button>
                    </AlertTitle>
                   <AlertDescription>{trafficReport.report}</AlertDescription>
                 </Alert>
              )}
              {/* Show selected incident summary or the new incident form */}
              {selectedIncident ? (
                <IncidentSummary 
                  incident={selectedIncident} 
                  onClear={() => setSelectedIncident(null)} 
                  onResolve={handleResolveIncident}
                  logs={logs}
                />
              ) : (
                <Accordion type="single" collapsible defaultValue="item-1" className="w-full border-b-0">
                  <AccordionItem value="item-1" className="border-b-0">
                    <AccordionTrigger className="pb-2">
                      <h2 className="text-lg font-semibold">New Incident</h2>
                    </AccordionTrigger>
                    <AccordionContent>
                      <NewIncidentForm 
                        addLog={addLog} 
                        createNewIncident={createNewIncident} 
                        clickedLocation={clickedLocation}
                        findClosestUnit={findUnitForDispatch}
                        clearClickedLocation={() => setClickedLocation(null)}
                      />
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              )}
            </div>
            {/* Tabs for switching between fleet status and system log */}
            <Tabs defaultValue="fleet" className="flex-grow flex flex-col">
              <TabsList className="w-full">
                <TabsTrigger value="fleet" className="w-full">Fleet Status</TabsTrigger>
                <TabsTrigger value="log" className="w-full">System Log</TabsTrigger>
              </TabsList>
              <TabsContent value="fleet" className="flex-grow overflow-y-auto mt-2">
                <FleetStatus responders={responders} />
              </TabsContent>
              <TabsContent value="log" className="flex-grow overflow-y-auto mt-2">
                <SystemLog logs={logs} />
              </TabsContent>
            </Tabs>
          </div>
        );
    }
  };

  // Special layout for the analytics dashboard to give it more space.
  if (view === 'analytics') {
    return (
        <div className="md:w-3/5 lg:w-2/5 h-screen overflow-y-auto bg-[--bg-primary]">
            {renderView()}
        </div>
    )
  }

  // Default layout for the main dashboard.
  return (
    <div className="md:w-2/5 h-screen overflow-y-auto p-4 flex flex-col bg-[--bg-primary]">
      <div className="flex-shrink-0 border-b pb-4 flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dispatch Command Center</h1>
          <p className="text-sm text-muted-foreground">Live Incident & Fleet Management</p>
        </div>
        <div className="flex flex-col items-end gap-2">
            <div className='flex items-center gap-2'>
                <Button variant="outline" size="sm" onClick={handleGetTrafficReport} disabled={isTrafficPending}>
                    <TrafficCone className="mr-2 h-4 w-4"/>Traffic
                </Button>
                <Button variant="outline" size="sm" onClick={() => setView('analytics')}>
                    <LineChart className="mr-2 h-4 w-4"/>Analytics
                </Button>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">Guides</Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setView('fleet')}>
                            <Siren className="mr-2 h-4 w-4"/>Fleet Guide
                        </DropdownMenuItem>
                         <DropdownMenuItem onClick={() => setView('hospital')}>
                            <HospitalIcon className="mr-2 h-4 w-4"/>Hospital Guide
                        </DropdownMenuItem>
                         <DropdownMenuItem onClick={() => setView('incident')}>
                            <BookOpen className="mr-2 h-4 w-4"/>Incident Guide
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
            <ThemeToggle />
        </div>
      </div>
      {renderView()}
    </div>
  );
}

    
