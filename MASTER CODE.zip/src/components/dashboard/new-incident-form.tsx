
'use client';

import { useState, useTransition, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { incidentTypes } from '@/lib/data';
import type { Incident, LogEntry, Location, Responder } from '@/lib/types';
import { getProtocol } from '@/ai/flows/get-protocol';
import { analyzeReport, type AnalyzeReportOutput } from '@/ai/flows/analyze-report';
import { getDispatchPackage } from '@/ai/flows/get-dispatch-package';

import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Bot, AlertTriangle, CheckCircle, RefreshCw, Mic } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

/**
 * Props for the NewIncidentForm component.
 */
interface NewIncidentFormProps {
  addLog: (message: string, level: LogEntry['level'], incidentId?: string) => void;
  createNewIncident: (incidentData: Omit<Incident, 'id' | 'timestamp' | 'status'>, requiredUnits?: { unitType: string, quantity: number }[]) => Promise<Incident>;
  clickedLocation: Location | null;
  findClosestUnit: (location: Location, unitType: string) => Responder | null;
  clearClickedLocation: () => void;
}

// Zod schema for form validation.
const formSchema = z.object({
  report: z.string().min(1, 'Please provide a report.'),
  language: z.string().min(1, 'Language is required.'),
  location: z.string().regex(/^-?\d+(\.\d+)?,\s*-?\d+(\.\d+)?$/, 'Invalid location format (lat, lng).'),
});

type FormData = z.infer<typeof formSchema>;

/**
 * Structure for the data required by the dispatch confirmation dialog.
 */
interface ConfirmationData {
  incidentType: string;
  location: string;
  unit: Responder | null;
  formData: FormData;
  isPackage: boolean;
  packageDetails?: { unitType: string, quantity: number }[];
}

export default function NewIncidentForm({ addLog, createNewIncident, clickedLocation, findClosestUnit, clearClickedLocation }: NewIncidentFormProps) {
  // State for managing AI analysis loading state.
  const [isAiPending, startAiTransition] = useTransition();
  // State for managing dispatch planning loading state.
  const [isDispatchPending, startDispatchTransition] = useTransition();
  // State to store the results from the AI analysis flow.
  const [analysisResult, setAnalysisResult] = useState<AnalyzeReportOutput | null>(null);
  // State to store any errors from the AI analysis.
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  // State to manage the currently selected incident type (can be overridden by the user).
  const [selectedIncidentType, setSelectedIncidentType] = useState<string | null>(null);

  // State to store the AI-generated protocol steps.
  const [aiProtocol, setAiProtocol] = useState<string[] | null>(null);
  
  // State to manage the data for the confirmation dialog.
  const [confirmationData, setConfirmationData] = useState<ConfirmationData | null>(null);
  // State to simulate voice input activation.
  const [isListening, setIsListening] = useState(false);

  // React Hook Form setup.
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      report: '',
      language: 'en-IN',
      location: '',
    },
  });

  // Effect to update the form's location field when the user clicks on the map.
  useEffect(() => {
    if (clickedLocation) {
      const { lat, lng } = clickedLocation;
      form.setValue('location', `${lat.toFixed(6)}, ${lng.toFixed(6)}`);
    }
  }, [clickedLocation, form]);
  
  /**
   * Handles the submission of the new incident form to start the AI analysis.
   * @param data - The validated form data.
   */
  const handleAnalyzeReport = (data: FormData) => {
    startAiTransition(async () => {
      handleClear(false); // Clear previous results but not form data
      addLog('Analyzing caller report with AI...', 'ai');
      try {
        const result = await analyzeReport({ report: data.report, language: data.language });
        setAnalysisResult(result);
        setSelectedIncidentType(result.incidentType);
        addLog(`AI analysis complete. Incident type: ${result.incidentType}`, 'ai');
        
        // Automatically fetch protocol after successful analysis.
        const protocolResult = await getProtocol({ incidentType: result.incidentType });
        setAiProtocol(protocolResult.protocolSteps);
        addLog('AI protocol received.', 'ai');
      } catch (e) {
        addLog('Failed to analyze report or fetch protocol.', 'error');
        setAnalysisError('AI analysis failed. Please check the report or try again.');
      }
    });
  };

  /**
   * Handles manual changes to the incident type from the dropdown.
   * Fetches a new protocol based on the newly selected type.
   * @param newIncidentType - The incident type selected by the user.
   */
  const handleIncidentTypeChange = async (newIncidentType: string) => {
    setSelectedIncidentType(newIncidentType);
    addLog(`Manual override: Incident type changed to ${newIncidentType}`, 'info');
    try {
        const protocolResult = await getProtocol({ incidentType: newIncidentType });
        setAiProtocol(protocolResult.protocolSteps);
        addLog('AI protocol updated for new incident type.', 'ai');
    } catch (e) {
        addLog('Failed to fetch protocol for manually selected type.', 'error');
    }
  };

  /**
   * Initiates the dispatch process by determining the required units
   * and showing the confirmation dialog.
   */
  const handleDispatch = () => {
    startDispatchTransition(async () => {
        if (!selectedIncidentType) return;

        const incidentType = selectedIncidentType;
        const locationStr = form.getValues('location');
        const [lat, lng] = locationStr.split(',').map(Number);
        
        const incidentDetails = incidentTypes.find(i => i.name === incidentType);
        if (!incidentDetails) {
            addLog(`Invalid incident type for dispatch: ${incidentType}`, 'error');
            return;
        }

        let packageDetails: { unitType: string, quantity: number }[] = [];
        
        // Handle pre-defined disaster packages.
        if (incidentDetails.type === 'Disaster') {
            addLog(`Disaster protocol activated. Assembling pre-defined package.`, 'dispatch');
            packageDetails = [
                { unitType: 'Type F (Disaster)', quantity: 1 },
                { unitType: 'Type C (ALS)', quantity: 2 },
                { unitType: 'Fire Engine', quantity: 2 },
            ];
            setConfirmationData({
                incidentType, location: locationStr, unit: null, formData: form.getValues(), isPackage: true, packageDetails
            });
        // Handle AI-recommended packages for other complex incidents.
        } else if (incidentDetails.requiresPackage) {
            addLog(`Fetching AI recommendation for dispatch package...`, 'ai');
            try {
                const { dispatchPackage } = await getDispatchPackage({ incidentType });
                addLog(`AI recommended package: ${dispatchPackage.map(p => `${p.quantity}x ${p.unitType}`).join(', ')}`, 'ai');
                packageDetails = dispatchPackage;
                 setConfirmationData({
                    incidentType, location: locationStr, unit: null, formData: form.getValues(), isPackage: true, packageDetails
                });
            } catch (e) {
                addLog('AI package recommendation failed.', 'error');
            }
        // Handle standard single-unit dispatches.
        } else {
            const closestUnit = findClosestUnit({ lat, lng }, incidentDetails.recommendedUnit);
            if (closestUnit) {
                setConfirmationData({
                    incidentType, location: locationStr, unit: closestUnit, formData: form.getValues(), isPackage: false
                });
            } else {
                addLog(`No available units for incident type: ${incidentType}`, 'error');
            }
        }
    });
  };
  
  /**
   * Finalizes the dispatch after user confirmation.
   * Calls the `createNewIncident` function with all necessary data.
   */
  const handleConfirmDispatch = async () => {
    if (!confirmationData) return;
    const { formData, incidentType, packageDetails } = confirmationData;
    const [lat, lng] = formData.location.split(',').map(Number);
    
    // Determine the final list of units to be dispatched.
    const requiredUnits = confirmationData.isPackage 
        ? packageDetails 
        : [{ unitType: incidentTypes.find(i => i.name === incidentType)!.recommendedUnit, quantity: 1 }];

    const newIncident = await createNewIncident({
      type: incidentType,
      location: { lat, lng },
      description: formData.report.substring(0, 50) || 'No description',
      report: formData.report,
    }, requiredUnits);
    
    addLog(`Dispatch confirmed for incident ${newIncident.id}.`, 'dispatch');
    handleClear(true);
  };

  /**
   * Clears the form and all related state.
   * @param clearForm - Whether to reset the form fields.
   */
  const handleClear = (clearForm: boolean = true) => {
    if (clearForm) {
      form.reset();
      clearClickedLocation();
    }
    setAnalysisResult(null);
    setAnalysisError(null);
    setSelectedIncidentType(null);
    setAiProtocol(null);
    setConfirmationData(null);
  };
  
  /**
   * Toggles the mock voice input state.
   * Note: This does not implement the actual Web Speech API.
   */
  const handleVoiceInput = () => {
    setIsListening(prev => !prev);
    if (!isListening) {
      addLog('Voice input activated. (Mock)', 'info');
    } else {
      addLog('Voice input deactivated. (Mock)', 'info');
    }
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleAnalyzeReport)} className="space-y-4">
        <FormField
          control={form.control}
          name="report"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Caller Report</FormLabel>
              <FormControl>
                <div className="relative">
                   <Textarea 
                      placeholder={isListening ? "Listening..." : "Enter the full report from the caller..."} 
                      {...field} 
                      rows={5}
                      className="pr-10"
                    />
                   <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      onClick={handleVoiceInput}
                      className={cn("absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8", isListening && "text-red-500 animate-pulse")}
                    >
                      <Mic className="h-4 w-4" />
                      <span className="sr-only">Use Voice Input</span>
                   </Button>
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-2 gap-4">
            <FormField
            control={form.control}
            name="language"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Language</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                    <SelectTrigger>
                        <SelectValue placeholder="Select language..." />
                    </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        <SelectItem value="en-IN">English (India)</SelectItem>
                        <SelectItem value="hi-IN">Hindi</SelectItem>
                        <SelectItem value="kn-IN">Kannada</SelectItem>
                    </SelectContent>
                </Select>
                <FormMessage />
                </FormItem>
            )}
            />
            <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Location (Lat, Lng)</FormLabel>
                <FormControl>
                    <Input placeholder="Click map or enter manually" {...field} />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
        </div>
        
        <div className="flex items-center gap-2">
            <Button type="submit" className="flex-grow" disabled={isAiPending}>
                <Bot className="mr-2 h-4 w-4" /> {isAiPending ? 'Analyzing...' : 'Analyze with AI'}
            </Button>
            <Button type="button" variant="outline" size="icon" onClick={() => handleClear(true)} aria-label="Clear Form">
                <RefreshCw className="h-4 w-4" />
            </Button>
        </div>
        
        {/* UI for displaying AI analysis results, loading states, and errors */}
        {isAiPending && <Skeleton className="h-24 w-full" />}
        
        {analysisResult && (
             <Card className="bg-accent/10 border-accent/30">
                <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-base flex items-center justify-between text-accent">
                        <div className="flex items-center">
                            <CheckCircle className="mr-2 h-4 w-4" /> AI Analysis Complete
                        </div>
                        <Badge variant="secondary">Confidence: {analysisResult.confidenceScore}</Badge>
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 text-sm space-y-3">
                    <div className="space-y-1">
                        <div><strong>Key Factors:</strong> {analysisResult.keyFactors.join(', ')}</div>
                        {analysisResult.translatedReport && (
                            <div className="text-xs italic text-muted-foreground pt-1">
                            <strong>Translated Report:</strong> "{analysisResult.translatedReport}"
                            </div>
                        )}
                    </div>
                    {/* Dropdown to allow manual override of AI's classification */}
                    {selectedIncidentType && (
                        <FormItem>
                            <FormLabel>Incident Type (Manual Override)</FormLabel>
                            <Select onValueChange={handleIncidentTypeChange} value={selectedIncidentType}>
                                <FormControl>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select incident type..." />
                                </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {incidentTypes.map(type => (
                                        <SelectItem key={type.name} value={type.name}>{type.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </FormItem>
                    )}
                </CardContent>
            </Card>
        )}

        {aiProtocol && (
            <Card className="bg-accent/10 border-accent/30">
                <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-base flex items-center text-accent">
                        <Bot className="mr-2 h-4 w-4" /> AI-Generated Guidance
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 text-sm">
                    <ul className="list-disc pl-5">
                        {aiProtocol.map((step, i) => <li key={i}>{step}</li>)}
                    </ul>
                </CardContent>
            </Card>
        )}

        {analysisError && (
            <Card className="bg-destructive/10 border-destructive/30">
                 <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-base flex items-center text-destructive">
                        <AlertTriangle className="mr-2 h-4 w-4" /> Analysis Error
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0 text-sm">
                   {analysisError}
                </CardContent>
            </Card>
        )}

        {analysisResult && !isAiPending && (
            <div className="flex items-center gap-2">
                <Button type="button" className="flex-grow" onClick={handleDispatch} disabled={isDispatchPending}>
                    {isDispatchPending ? 'Planning Dispatch...' : 'Dispatch Unit'}
                </Button>
            </div>
        )}
      </form>

      {/* Dispatch Confirmation Dialog */}
      {confirmationData && (
        <AlertDialog open onOpenChange={() => setConfirmationData(null)}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Dispatch</AlertDialogTitle>
                    <AlertDialogDescription>
                        Please review the details before dispatching.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="space-y-2 text-left text-sm text-muted-foreground pt-2">
                        <div><strong>Incident:</strong> {confirmationData.incidentType}</div>
                        <div><strong>Location:</strong> {confirmationData.location}</div>
                        {confirmationData.isPackage ? (
                             <div>
                                <strong>Dispatch Package:</strong>
                                <ul className="list-disc pl-5 mt-1">
                                    {confirmationData.packageDetails?.map(p => (
                                        <li key={p.unitType}>{p.quantity}x {p.unitType}</li>
                                    ))}
                                </ul>
                             </div>
                        ) : (
                           <>
                            <div><strong>Dispatching Unit:</strong> {confirmationData.unit!.id} ({confirmationData.unit!.type})</div>
                            <div><strong>Current Location:</strong> {confirmationData.unit!.lat.toFixed(4)}, {confirmationData.unit!.lng.toFixed(4)}</div>
                           </>
                        )}
                    </div>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleConfirmDispatch}>Confirm Dispatch</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
      )}
    </Form>
  );
}
