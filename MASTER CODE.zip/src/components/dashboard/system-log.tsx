
'use client';

import type { LogEntry } from "@/lib/types";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface SystemLogProps {
    logs: LogEntry[];
}

const levelColors: { [key in LogEntry['level']]: string } = {
    info: 'text-[--log-info]',
    success: 'text-[--log-success]',
    error: 'text-[--log-error]',
    dispatch: 'text-[--log-dispatch] font-semibold',
    ai: 'text-[--log-ai]',
};

export default function SystemLog({ logs }: SystemLogProps) {
    return (
        <ScrollArea className="h-72 w-full rounded-md border p-4 font-mono text-xs">
           {logs.map((log, index) => (
               <div key={index} className="flex gap-2">
                   <span className="text-gray-400">{log.timestamp.toLocaleTimeString()}</span>
                   <p className={cn(levelColors[log.level])}>
                       {log.message}
                       {log.incidentId && <span className="text-gray-400 ml-2">({log.incidentId})</span>}
                   </p>
               </div>
           ))}
        </ScrollArea>
    );
}
