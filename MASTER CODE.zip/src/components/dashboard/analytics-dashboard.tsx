
'use client';

import type { Incident, Responder } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, LayoutDashboard } from 'lucide-react';
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { useMemo } from 'react';

interface AnalyticsDashboardProps {
  incidents: Incident[];
  responders: Responder[];
  onBack: () => void;
}

const PIE_COLORS = ['#16a34a', '#f97316', '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b'];
const TABLEAU_URL = 'https://public.tableau.com/views/EMERGENCYDIPATCHERDASHBOARD/Adhoc';

export default function AnalyticsDashboard({ incidents, responders, onBack }: AnalyticsDashboardProps) {
  const totalIncidents = incidents.length;
  const resolvedIncidents = incidents.filter(i => i.status === 'Resolved').length;
  const activeResponders = responders.filter(r => r.status !== 'Available').length;

  const incidentsByType = useMemo(() => {
    const counts: { [key: string]: number } = {};
    incidents.forEach(incident => {
      counts[incident.type] = (counts[incident.type] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, incidents: value }));
  }, [incidents]);

  const incidentsByHour = useMemo(() => {
    const counts: { [key: string]: number } = {};
    for(let i=0; i<24; i++) {
        const hour = i.toString().padStart(2, '0') + ':00';
        counts[hour] = 0;
    }
    incidents.forEach(incident => {
      const hour = new Date(incident.timestamp).getHours();
      const hourString = hour.toString().padStart(2, '0') + ':00';
      counts[hourString] = (counts[hourString] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, incidents: value }));
  }, [incidents]);

  const responderStatusDistribution = useMemo(() => {
    const counts: { [key: string]: number } = {};
    responders.forEach(responder => {
      counts[responder.status] = (counts[responder.status] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [responders]);

  return (
    <div className="flex flex-col h-full p-4 space-y-4">
      <div className="flex-shrink-0 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
            <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
            <p className="text-sm text-muted-foreground">Operational overview and key metrics.</p>
            </div>
        </div>
        <Button asChild>
            <a href={TABLEAU_URL} target="_blank" rel="noopener noreferrer">
              <LayoutDashboard className="mr-2 h-4 w-4" />
              Tableau Interface
            </a>
        </Button>
      </div>
      
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Total Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalIncidents}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Resolved Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{resolvedIncidents}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Active Responders</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{activeResponders}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 flex-grow">
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Incidents by Type</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={incidentsByType} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={60} interval={0} fontSize={12} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Legend />
                <Bar dataKey="incidents" fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Responder Status</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={responderStatusDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                   {responderStatusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

       <Card className="flex flex-col h-72">
          <CardHeader>
            <CardTitle>Incidents by Hour</CardTitle>
          </CardHeader>
          <CardContent className="flex-grow">
            <ResponsiveContainer width="100%" height="100%">
               <LineChart data={incidentsByHour} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis allowDecimals={false}/>
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="incidents" stroke="hsl(var(--primary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
    </div>
  );
}
