
'use client';
import { useState, useTransition } from 'react';
import type { Incident, LogEntry } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { summarizeIncident, type SummarizeIncidentOutput } from '@/ai/flows/summarize-incident';
import { debriefIncident, type DebriefIncidentOutput } from '@/ai/flows/debrief-incident';
import { Icons } from '@/components/icons';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { X, FileText } from 'lucide-react';
import IncidentDebrief from '@/components/incident/incident-debrief';

interface IncidentSummaryProps {
  incident: Incident;
  onClear: () => void;
  onResolve: (incidentId: string) => void;
  logs: LogEntry[];
}

export default function IncidentSummary({ incident, onClear, onResolve, logs }: IncidentSummaryProps) {
  const [isSummarizePending, startSummarizeTransition] = useTransition();
  const [isDebriefPending, startDebriefTransition] = useTransition();
  const [summaryResult, setSummaryResult] = useState<SummarizeIncidentOutput | null>(null);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const [debriefResult, setDebriefResult] = useState<DebriefIncidentOutput | null>(null);
  const [debriefError, setDebriefError] = useState<string | null>(null);
  const [isDebriefModalOpen, setDebriefModalOpen] = useState(false);


  const handleSummarize = () => {
    startSummarizeTransition(async () => {
      setSummaryError(null);
      setSummaryResult(null);
      try {
        const result = await summarizeIncident({ report: incident.report });
        setSummaryResult(result);
      } catch (e) {
        setSummaryError('Failed to generate summary. Please try again.');
      }
    });
  };

  const handleGenerateDebrief = () => {
    startDebriefTransition(async () => {
        setDebriefError(null);
        setDebriefResult(null);
        setDebriefModalOpen(true);
        try {
            const incidentLogs = logs
                .filter(log => log.incidentId === incident.id)
                .map(log => `${log.timestamp.toLocaleTimeString()} [${log.level.toUpperCase()}] ${log.message}`);

            const result = await debriefIncident({
                id: incident.id,
                type: incident.type,
                startTime: incident.timestamp,
                endTime: new Date().toISOString(), // Assuming now is end time
                unitId: incident.unitId || 'N/A',
                callerReport: incident.report,
                logs: incidentLogs,
            });
            setDebriefResult(result);
        } catch (e) {
            setDebriefError('Failed to generate incident debrief. Please try again.');
        }
    });
  };

  return (
    <div className="space-y-4">
       <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Selected Incident: {incident.id}</h2>
        <Button variant="ghost" size="icon" onClick={onClear}>
            <X className="h-4 w-4" />
        </Button>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Incident Report</CardTitle>
          <CardDescription>{incident.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-32">
            <p className="text-sm whitespace-pre-wrap">{incident.report}</p>
          </ScrollArea>
        </CardContent>
      </Card>
      <Card className="flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Icons.ai className="w-5 h-5 text-accent" />
                AI Summary
              </CardTitle>
              <CardDescription>Get a quick summary of the incident.</CardDescription>
            </div>
            <Button onClick={handleSummarize} disabled={isSummarizePending} size="sm" variant="outline">
              {isSummarizePending ? 'Summarizing...' : 'Summarize'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-1">
          {isSummarizePending && (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          )}
          {summaryError && (
             <Alert variant="destructive">
               <AlertTitle>Error</AlertTitle>
               <AlertDescription>{summaryError}</AlertDescription>
             </Alert>
          )}
          {summaryResult?.summary && (
            <ul className="list-disc space-y-2 pl-5 text-sm">
              {summaryResult.summary.split('- ').filter(s => s.trim()).map((point, index) => (
                <li key={index}>{point.trim()}</li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
       <div className="flex items-center gap-2">
        {incident.status !== 'Resolved' && (
            <Button onClick={() => onResolve(incident.id)} className="w-full">Mark as Resolved</Button>
        )}
        {incident.status === 'Resolved' && (
            <Button onClick={handleGenerateDebrief} disabled={isDebriefPending} className="w-full">
                <FileText className="mr-2 h-4 w-4" />
                {isDebriefPending ? 'Generating Debrief...' : 'Generate Incident Debrief'}
            </Button>
        )}
      </div>
       <IncidentDebrief
            isOpen={isDebriefModalOpen}
            onOpenChange={setDebriefModalOpen}
            incidentId={incident.id}
            isPending={isDebriefPending}
            error={debriefError}
            debriefData={debriefResult}
       />
    </div>
  );
}
