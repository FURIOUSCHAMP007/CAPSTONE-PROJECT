
'use client';

import type { Responder } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface FleetStatusProps {
    responders: Responder[];
}

const statusColors: { [key in Responder['status']]: string } = {
    'Available': 'bg-green-500/20 text-green-700 border-green-500/30',
    'Enroute to Incident': 'bg-orange-500/20 text-orange-700 border-orange-500/30',
    'On Scene': 'bg-blue-500/20 text-blue-700 border-blue-500/30',
    'At Scene - Deciding Hospital': 'bg-blue-500/20 text-blue-700 border-blue-500/30',
    'Enroute to Hospital': 'bg-purple-500/20 text-purple-700 border-purple-500/30',
    'At Hospital': 'bg-pink-500/20 text-pink-700 border-pink-500/30',
    'Returning to Base': 'bg-teal-500/20 text-teal-700 border-teal-500/30',
    'Awaiting Report': 'bg-slate-500/20 text-slate-700 border-slate-500/30',
};

export default function FleetStatus({ responders }: FleetStatusProps) {
    return (
        <div className="max-h-96 overflow-y-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Unit</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Incident</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {responders.map(responder => (
                        <TableRow key={responder.id}>
                            <TableCell className="font-medium">{responder.id}</TableCell>
                            <TableCell>{responder.type}</TableCell>
                            <TableCell>
                                <Badge variant="outline" className={cn("capitalize", statusColors[responder.status])}>
                                    {responder.status}
                                </Badge>
                            </TableCell>
                            <TableCell>{responder.incidentId || 'N/A'}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}
