
'use client';

import { useState, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import { initialResponders, initialHospitals, incidentTypes } from '@/lib/data';
import type { Incident, Responder, Hospital, Location, IncidentType, LogEntry } from '@/lib/types';
import DispatchDashboard from '@/components/dashboard/dispatch-dashboard';
import { getDistance, getRhumbLineBearing, computeDestinationPoint } from 'geolib';
import { recommendHospital } from '@/ai/flows/recommend-hospital';

// Dynamically import the MapView component to prevent SSR issues with map libraries.
const MapView = dynamic(() => import('@/components/map/map-view'), {
  ssr: false,
  loading: () => <div className="flex-grow h-screen bg-muted flex items-center justify-center"><p>Loading map...</p></div>
});

// Simulation constants
const SIMULATION_SPEED = 1600; // meters per second (a high value for demonstration)
const TICK_INTERVAL = 100; // milliseconds, how often the simulation updates

/**
 * The main layout component that combines the map and the dashboard.
 * It manages all the core application state and contains the simulation logic.
 */
export default function MapLayout() {
  // Core application state
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [responders, setResponders] = useState<Responder[]>(initialResponders);
  const [hospitals, setHospitals] = useState<Hospital[]>(initialHospitals);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [clickedLocation, setClickedLocation] = useState<Location | null>(null);
  // State for the system log entries
  const [logs, setLogs] = useState<LogEntry[]>([{ message: 'Dispatch Command Center Initialized.', level: 'success', timestamp: new Date() }]);
  // State for managing responder routes on the map
  const [routes, setRoutes] = useState<{ [key: string]: Location[] }>({});
  const [etas, setEtas] = useState<{ [key: string]: string }>({});

  /**
   * Adds a new entry to the system log.
   * @param message The log message.
   * @param level The severity level of the log entry.
   * @param incidentId Optional ID of the incident related to the log.
   */
  const addLog = useCallback((message: string, level: LogEntry['level'], incidentId?: string) => {
    // Add new logs to the beginning of the array.
    setLogs(prevLogs => [{ message, level, timestamp: new Date(), incidentId }, ...prevLogs]);
  }, []);

  /**
   * Fetches a route from an external API and updates the state.
   * @param responderId The ID of the responder to fetch the route for.
   * @param waypoints An array of locations representing the start and end points.
   */
  const updateRoute = useCallback(async (responderId: string, waypoints: Location[]) => {
      if (waypoints.length < 2) return;
      const coords = waypoints.map(p => `${p.lng},${p.lat}`).join(';');
      const url = `https://router.project-osrm.org/route/v1/driving/${coords}?geometries=geojson&overview=full`;
      
      try {
          const response = await fetch(url);
          const data = await response.json();
          if (data.routes && data.routes.length > 0) {
              const route = data.routes[0];
              const routeCoords = route.geometry.coordinates.map((c: number[]) => ({ lng: c[0], lat: c[1] }));
              
              setRoutes(prev => ({ ...prev, [responderId]: routeCoords }));

              const durationInMinutes = Math.round(route.duration / 60);
              setEtas(prev => ({...prev, [responderId]: `${durationInMinutes} min`}));
          }
      } catch (error) {
          console.error('Error fetching route:', error);
          addLog(`Route calculation failed for ${responderId}.`, 'error');
      }
  }, [addLog]);

  /**
   * Finds the closest hospital to a given location.
   * @param location The location to find the closest hospital to.
   * @returns The closest Hospital object.
   */
  const findClosestHospital = useCallback((location: Location): Hospital => {
    let closestHospital = hospitals[0];
    let minDistance = Infinity;

    hospitals.forEach(hospital => {
      const distance = getDistance(
        { latitude: location.lat, longitude: location.lng },
        { latitude: hospital.location.lat, longitude: hospital.location.lng }
      );
      if (distance < minDistance) {
        minDistance = distance;
        closestHospital = hospital;
      }
    });
    return closestHospital;
  }, [hospitals]);

  /**
   * Initiates a new leg of a journey for a responder (e.g., to hospital, back to base).
   * @param responderId The ID of the responder.
   * @param newStatus The responder's new status.
   * @param destination The new destination location.
   */
    const startNewLeg = useCallback((responderId: string, newStatus: Responder['status'], destination: Location) => {
        setResponders(prev => {
            const responder = prev.find(r => r.id === responderId);
            if (!responder) return prev;
            // Use setTimeout to defer the route update until after the state has been set.
            setTimeout(() => updateRoute(responderId, [responder, destination]), 0);
            return prev.map(r => 
                r.id === responderId ? { ...r, status: newStatus, routeIndex: 0 } : r
            );
        });
    }, [updateRoute]);

  /**
   * Gets an AI-powered hospital recommendation.
   * @param incident The incident requiring hospitalization.
   * @returns A promise that resolves to the recommended Hospital object, or null.
   */
  const getAIHospitalRecommendation = useCallback(async (incident: Incident): Promise<Hospital | null> => {
    addLog(`Getting AI hospital recommendation for incident ${incident.id}`, 'ai', incident.id);
    try {
        const incidentDetails = incidentTypes.find(i => i.name === incident.type);
        if (!incidentDetails) {
            addLog(`Could not find details for incident type: ${incident.type}`, 'error', incident.id);
            return null;
        }

        const nearbyHospitals = hospitals.map(h => ({
            name: h.name,
            capabilities: h.capabilities,
            beds: h.beds,
            distance: `${(getDistance({latitude: incident.location.lat, longitude: incident.location.lng}, {latitude: h.location.lat, longitude: h.location.lng}) / 1000).toFixed(2)} km`
        }));
        
        const result = await recommendHospital({
            incidentType: incident.type,
            requiredCapability: incidentDetails.hospitalCapability,
            hospitals: nearbyHospitals,
        });

        addLog(`AI recommends ${result.hospitalName}. Reason: ${result.reasoning}`, 'ai', incident.id);

        const recommended = hospitals.find(h => h.name === result.hospitalName);
        return recommended || null;

    } catch(e) {
        addLog(`AI hospital recommendation failed. Falling back to closest hospital.`, 'error', incident.id);
        return findClosestHospital(incident.location);
    }
}, [hospitals, findClosestHospital, addLog]);

  // Effect to handle hospital recommendation when a unit arrives on scene
  useEffect(() => {
    responders.forEach(responder => {
      if (responder.status === 'On Scene') {
        const incident = incidents.find(i => i.id === responder.incidentId);
        const incidentDetails = incident ? incidentTypes.find(it => it.name === incident.type) : null;
        
        if (incident && incidentDetails && ['ALS', 'BLS', 'ICU', 'Maternity'].includes(incidentDetails.hospitalCapability)) {
          // Immediately update responder status to prevent re-triggering
          setResponders(prev => prev.map(r => r.id === responder.id ? { ...r, status: 'At Scene - Deciding Hospital' } : r));

          getAIHospitalRecommendation(incident).then(hospital => {
            if (hospital) {
              addLog(`Unit ${responder.id} transporting patient to ${hospital.name}.`, 'dispatch', incident.id);
              startNewLeg(responder.id, 'Enroute to Hospital', hospital.location);
            }
          });
        }
      }
    });
  }, [responders, incidents, getAIHospitalRecommendation, addLog, startNewLeg]);

  // Main simulation loop
  useEffect(() => {
    const simulationInterval = setInterval(() => {
      setResponders(prevResponders => {
        let needsUpdate = false;
        const updatedResponders = prevResponders.map(responder => {
            const route = routes[responder.id];
            if (!route || responder.status === 'Available' || responder.status === 'Awaiting Report' || typeof responder.routeIndex === 'undefined' || responder.status === 'On Scene' || responder.status === 'At Scene - Deciding Hospital') {
                return responder;
            }
            
            const currentLegIndex = responder.routeIndex;
            
            if (currentLegIndex >= route.length - 1) {
                // Responder has reached the end of the current route leg
                needsUpdate = true;
                const incident = incidents.find(i => i.id === responder.incidentId);

                switch(responder.status) {
                    case 'Enroute to Incident':
                        if (incident) {
                            addLog(`Unit ${responder.id} has arrived on scene at incident ${incident.id}.`, 'dispatch', incident.id);
                            const incidentDetails = incidentTypes.find(i => i.name === incident.type);
                            if (incidentDetails && ['ALS', 'BLS', 'ICU', 'Maternity'].includes(incidentDetails.hospitalCapability)) {
                                return { ...responder, status: 'On Scene', routeIndex: undefined };
                            } else {
                                addLog(`Unit ${responder.id} awaiting report at ${incident.id}.`, 'dispatch', incident.id);
                                return { ...responder, status: 'Awaiting Report', routeIndex: undefined, incidentId: null };
                            }
                        }
                        break;
                    case 'Enroute to Hospital':
                        addLog(`Unit ${responder.id} has arrived at the hospital.`, 'dispatch', responder.incidentId!);
                        startNewLeg(responder.id, 'Returning to Base', responder.baseLocation);
                        return { ...responder, status: 'At Hospital', routeIndex: undefined };
                    
                    case 'Returning to Base':
                        addLog(`Unit ${responder.id} has returned to base and is now available.`, 'dispatch');
                        setEtas(prev => {
                          const newEtas = {...prev};
                          delete newEtas[responder.id];
                          return newEtas;
                        });
                        return { ...responder, lat: responder.baseLocation.lat, lng: responder.baseLocation.lng, status: 'Available', incidentId: null, routeIndex: undefined };
                }

                return responder;
            }
            
            // Move responder along the route
            needsUpdate = true;
            const nextPoint = route[currentLegIndex + 1];
            return {
                ...responder,
                lat: nextPoint.lat,
                lng: nextPoint.lng,
                routeIndex: currentLegIndex + 1,
            };
        });

        return needsUpdate ? updatedResponders : prevResponders;
      });
    }, TICK_INTERVAL);

    return () => clearInterval(simulationInterval);
  }, [routes, incidents, addLog, startNewLeg]);

  const routesGeoJSON = Object.values(routes).map(route => route.map(p => [p.lng, p.lat]));

  return (
    <div className="flex flex-col md:flex-row h-screen">
       <div className="flex-grow h-screen bg-muted">
          <MapView
            incidents={incidents}
            responders={responders}
            hospitals={hospitals}
            selectedIncident={selectedIncident}
            onMapClick={setClickedLocation}
            routesGeoJSON={routesGeoJSON}
            etas={etas}
          />
      </div>
      <DispatchDashboard 
        incidents={incidents}
        setIncidents={setIncidents}
        selectedIncident={selectedIncident}
        setSelectedIncident={setSelectedIncident}
        responders={responders}
        setResponders={setResponders}
        hospitals={hospitals}
        clickedLocation={clickedLocation}
        setClickedLocation={setClickedLocation}
        updateRoute={updateRoute}
        addLog={addLog}
        logs={logs}
      />
    </div>
  );
}
