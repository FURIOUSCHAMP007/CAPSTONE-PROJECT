'use client';
import { useState, useTransition } from 'react';
import type { Incident } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { summarizeIncident, type SummarizeIncidentOutput } from '@/ai/flows/summarize-incident';
import { Icons } from '@/components/icons';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface IncidentDetailsProps {
  incident: Incident;
}

export default function IncidentDetails({ incident }: IncidentDetailsProps) {
  const [isPending, startTransition] = useTransition();
  const [summaryResult, setSummaryResult] = useState<SummarizeIncidentOutput | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSummarize = () => {
    startTransition(async () => {
      setError(null);
      setSummaryResult(null);
      try {
        const result = await summarizeIncident({ report: incident.report });
        setSummaryResult(result);
      } catch (e) {
        setError('Failed to generate summary. Please try again.');
      }
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Incident Report: {incident.id}</CardTitle>
          <CardDescription>{incident.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <p className="text-sm whitespace-pre-wrap">{incident.report}</p>
          </ScrollArea>
        </CardContent>
      </Card>
      <Card className="flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Icons.ai className="w-5 h-5 text-accent" />
                AI Summary
              </CardTitle>
              <CardDescription>Get a quick summary of the incident.</CardDescription>
            </div>
            <Button onClick={handleSummarize} disabled={isPending} size="sm" variant="outline">
              {isPending ? 'Summarizing...' : 'Summarize'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-1">
          {isPending && (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          )}
          {error && (
             <Alert variant="destructive">
               <AlertTitle>Error</AlertTitle>
               <AlertDescription>{error}</AlertDescription>
             </Alert>
          )}
          {summaryResult?.summary && (
            <ul className="list-disc space-y-2 pl-5 text-sm">
              {summaryResult.summary.split('- ').filter(s => s.trim()).map((point, index) => (
                <li key={index}>{point.trim()}</li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
