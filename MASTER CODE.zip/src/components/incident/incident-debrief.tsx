
'use client';

import type { DebriefIncidentOutput } from '@/ai/flows/debrief-incident';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertTriangle, Lightbulb, Download } from 'lucide-react';

interface IncidentDebriefProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  incidentId: string;
  isPending: boolean;
  error: string | null;
  debriefData: DebriefIncidentOutput | null;
}

export default function IncidentDebrief({ isOpen, onOpenChange, incidentId, isPending, error, debriefData }: IncidentDebriefProps) {

  const formatDebriefForDownload = (data: DebriefIncidentOutput): string => {
    let content = `# ${data.title}\n\n`;
    content += `**Incident ID:** ${incidentId}\n\n`;
    content += `## Summary\n${data.summary}\n\n`;
    
    content += `## Incident Timeline\n`;
    data.timeline.forEach(event => {
      content += `- **${event.time}:** ${event.description}\n`;
    });
    content += `\n`;

    content += `## Response Analysis\n`;
    content += `### What Went Well\n`;
    data.analysis.whatWentWell.forEach(point => {
      content += `- ${point}\n`;
    });
    content += `\n`;

    content += `### Areas for Improvement\n`;
    data.analysis.areasForImprovement.forEach(point => {
      content += `- ${point}\n`;
    });
    content += `\n`;

    content += `## Key Takeaway\n`;
    content += `${data.keyTakeaway}\n`;

    return content;
  };

  const handleDownload = () => {
    if (!debriefData) return;

    const content = formatDebriefForDownload(debriefData);
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `debrief-${incidentId}.md`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Incident Debrief: {incidentId}</DialogTitle>
          <DialogDescription>
            AI-generated analysis of the incident response and key takeaways.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh] p-4 pr-6">
          {isPending && (
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-16 w-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
              </div>
            </div>
          )}
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {debriefData && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">{debriefData.title}</h3>
                <p className="text-sm text-muted-foreground">{debriefData.summary}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Incident Timeline</h4>
                <div className="relative pl-6">
                  <div className="absolute left-0 top-0 h-full w-0.5 bg-border rounded" />
                  {debriefData.timeline.map((event, index) => (
                    <div key={index} className="relative mb-4">
                      <div className="absolute -left-[30.5px] top-1 h-4 w-4 bg-background border-2 border-primary rounded-full" />
                      <p className="font-mono text-xs text-primary">{event.time}</p>
                      <p className="text-sm">{event.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Response Analysis</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="rounded-lg border bg-card p-4">
                        <h5 className="flex items-center font-medium mb-2 text-green-600"><CheckCircle className="h-4 w-4 mr-2"/>What Went Well</h5>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                            {debriefData.analysis.whatWentWell.map((point, i) => <li key={i}>{point}</li>)}
                        </ul>
                    </div>
                     <div className="rounded-lg border bg-card p-4">
                        <h5 className="flex items-center font-medium mb-2 text-amber-600"><AlertTriangle className="h-4 w-4 mr-2"/>Areas for Improvement</h5>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                            {debriefData.analysis.areasForImprovement.map((point, i) => <li key={i}>{point}</li>)}
                        </ul>
                    </div>
                </div>
              </div>

              <Alert className="bg-accent/20 border-accent/40">
                <Lightbulb className="h-4 w-4" />
                <AlertTitle>Key Takeaway</AlertTitle>
                <AlertDescription>
                  {debriefData.keyTakeaway}
                </AlertDescription>
              </Alert>
            </div>
          )}
        </ScrollArea>
        {debriefData && !isPending && (
          <DialogFooter className="pt-4">
            <Button onClick={handleDownload}>
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
