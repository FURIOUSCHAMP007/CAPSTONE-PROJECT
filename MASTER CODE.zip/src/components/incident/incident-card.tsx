import type { Incident } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';
import { Icons } from '@/components/icons';

interface IncidentCardProps {
  incident: Incident;
  isSelected: boolean;
  onClick: () => void;
}

const statusColors: { [key in Incident['status']]: string } = {
  'New': 'bg-red-500 hover:bg-red-600',
  'In Progress': 'bg-yellow-500 hover:bg-yellow-600 text-yellow-900',
  'Resolved': 'bg-green-500 hover:bg-green-600',
};

const typeIcons = {
    'Medical': <Icons.medical className="h-5 w-5 text-red-500" />,
    'Fire': <Icons.fire className="h-5 w-5 text-orange-500" />,
    'Crime': <Icons.crime className="h-5 w-5 text-blue-500" />
}

export default function IncidentCard({ incident, isSelected, onClick }: IncidentCardProps) {
  return (
    <Card
      className={cn(
        'p-3 mb-2 cursor-pointer transition-all duration-200 ease-in-out hover:shadow-md',
        isSelected ? 'bg-primary/20 border-primary' : 'bg-card'
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-background rounded-full">
            {typeIcons[incident.type]}
          </div>
          <div>
            <p className="font-semibold">{incident.id} - {incident.type}</p>
            <p className="text-sm text-muted-foreground">{incident.description}</p>
          </div>
        </div>
        <Badge
          className={cn('text-white text-xs', statusColors[incident.status])}
        >
          {incident.status}
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground text-right mt-2">
        {formatDistanceToNow(new Date(incident.timestamp), { addSuffix: true })}
      </p>
    </Card>
  );
}
