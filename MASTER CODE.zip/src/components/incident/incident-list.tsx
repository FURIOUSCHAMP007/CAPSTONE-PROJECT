import type { Incident } from '@/lib/types';
import { ScrollArea } from '@/components/ui/scroll-area';
import IncidentCard from './incident-card';
import { Icons } from '@/components/icons';
import { Separator } from '@/components/ui/separator';

interface IncidentListProps {
  incidents: Incident[];
  selectedIncident: Incident | null;
  onSelectIncident: (incident: Incident) => void;
}

export default function IncidentList({ incidents, selectedIncident, onSelectIncident }: IncidentListProps) {
  return (
    <div className="flex flex-col h-full">
      <header className="p-4 border-b">
        <h1 className="text-2xl font-bold tracking-tight">Dispatch Assistant</h1>
        <p className="text-sm text-muted-foreground">Live Incident Feed</p>
      </header>
      <ScrollArea className="flex-1">
        <div className="p-2">
          {incidents.map((incident) => (
            <IncidentCard
              key={incident.id}
              incident={incident}
              isSelected={selectedIncident?.id === incident.id}
              onClick={() => onSelectIncident(incident)}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
