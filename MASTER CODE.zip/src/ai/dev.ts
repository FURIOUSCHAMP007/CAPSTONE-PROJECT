import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-incident.ts';
import '@/ai/flows/analyze-report';
import '@/ai/flows/get-protocol';
import '@/ai/flows/get-dispatch-package';
import '@/ai/flows/get-traffic-report';
import '@/ai/flows/generate-incident-report';
import '@/ai/flows/recommend-hospital';
import '@/ai/flows/debrief-incident';
