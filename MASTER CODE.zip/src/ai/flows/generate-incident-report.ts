'use server';

/**
 * @fileOverview Generates a post-incident report.
 *
 * - generateIncidentReport - A function that creates a summary report.
 * - GenerateIncidentReportInput - The input type for the function.
 * - GenerateIncidentReportOutput - The return type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateIncidentReportInputSchema = z.object({
  id: z.string(),
  type: z.string(),
  startTime: z.string(),
  unitId: z.string(),
  callerReport: z.string(),
});
export type GenerateIncidentReportInput = z.infer<typeof GenerateIncidentReportInputSchema>;

const GenerateIncidentReportOutputSchema = z.object({
  report: z.string().describe('A post-incident summary in Markdown format.'),
});
export type GenerateIncidentReportOutput = z.infer<typeof GenerateIncidentReportOutputSchema>;

export async function generateIncidentReport(input: GenerateIncidentReportInput): Promise<GenerateIncidentReportOutput> {
  return generateIncidentReportFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateIncidentReportPrompt',
  input: { schema: GenerateIncidentReportInputSchema },
  output: { schema: GenerateIncidentReportOutputSchema },
  prompt: `
        Generate a concise post-incident report in Markdown format.
        - Incident ID: {{id}}
        - Incident Type: {{type}}
        - Dispatch Time: {{startTime}}
        - Responding Unit: {{unitId}}
        - Initial Caller Report: "{{callerReport}}"

        Summarize the event and list 3 plausible actions taken by the responding unit based on the incident type.
    `,
});

const generateIncidentReportFlow = ai.defineFlow(
  {
    name: 'generateIncidentReportFlow',
    inputSchema: GenerateIncidentReportInputSchema,
    outputSchema: GenerateIncidentReportOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
