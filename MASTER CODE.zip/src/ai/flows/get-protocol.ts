'use server';

/**
 * @fileOverview Generates an immediate action protocol for a given incident type.
 *
 * - getProtocol - A function that returns a protocol checklist.
 * - GetProtocolInput - The input type for the getProtocol function.
 * - GetProtocolOutput - The return type for the getProtocol function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GetProtocolInputSchema = z.object({
  incidentType: z.string().describe('The type of incident.'),
});
export type GetProtocolInput = z.infer<typeof GetProtocolInputSchema>;

const GetProtocolOutputSchema = z.object({
  protocolSteps: z.array(z.string()).describe('A checklist of immediate questions or actions for the dispatcher.'),
});
export type GetProtocolOutput = z.infer<typeof GetProtocolOutputSchema>;

export async function getProtocol(input: GetProtocolInput): Promise<GetProtocolOutput> {
  return getProtocolFlow(input);
}

const prompt = ai.definePrompt({
  name: 'getProtocolPrompt',
  input: { schema: GetProtocolInputSchema },
  output: { schema: GetProtocolOutputSchema },
  prompt: `
        Generate a checklist of 3-4 critical, immediate questions or actions for an emergency dispatcher handling a "{{incidentType}}" incident.
        These should be concise instructions to relay to the caller or the responding units.
    `,
});

const getProtocolFlow = ai.defineFlow(
  {
    name: 'getProtocolFlow',
    inputSchema: GetProtocolInputSchema,
    outputSchema: GetProtocolOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
