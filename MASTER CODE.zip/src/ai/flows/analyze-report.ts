'use server';

/**
 * @fileOverview Analyzes a caller's report to determine incident type.
 *
 * - analyzeReport - A function that analyzes a caller's report.
 * - AnalyzeReportInput - The input type for the analyzeReport function.
 * - AnalyzeReportOutput - The return type for the analyzeReport function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { incidentTypes } from '@/lib/data';

// Define the schema for the input data for the analysis flow.
const AnalyzeReportInputSchema = z.object({
  report: z.string().describe('The full text of the caller report.'),
  language: z.string().describe('The language code of the report (e.g., "en-IN", "hi-IN").'),
});
export type AnalyzeReportInput = z.infer<typeof AnalyzeReportInputSchema>;

// Define the schema for the output data from the analysis flow.
const AnalyzeReportOutputSchema = z.object({
  incidentType: z.string().describe('The most likely incident type from the provided list.'),
  confidenceScore: z.string().describe('A percentage indicating the confidence in the choice.'),
  keyFactors: z.array(z.string()).describe('The key phrases from the report that influenced the decision.'),
  translatedReport: z.string().optional().describe('The English translation of the report if translation was performed.'),
});
export type AnalyzeReportOutput = z.infer<typeof AnalyzeReportOutputSchema>;

/**
 * Public function to trigger the report analysis flow.
 * @param input The caller report and language.
 * @returns A promise that resolves to the analysis result.
 */
export async function analyzeReport(input: AnalyzeReportInput): Promise<AnalyzeReportOutput> {
  return analyzeReportFlow(input);
}

// Generate a comma-separated list of incident names for the prompt.
const incidentNameList = incidentTypes.map(i => `"${i.name}"`).join(", ");

// Define a Genkit prompt specifically for translating non-English reports.
const translationPrompt = ai.definePrompt({
    name: 'translateReportPrompt',
    input: { schema: z.object({ report: z.string() }) },
    prompt: `Translate the following text to English: {{{report}}}`,
});

// Define the main analysis prompt with few-shot examples for better accuracy.
const analysisPrompt = ai.definePrompt({
  name: 'analyzeReportPrompt',
  input: { schema: z.object({ report: z.string() }) },
  output: { schema: AnalyzeReportOutputSchema },
  prompt: `
        You are an expert emergency dispatcher AI. Your task is to analyze an emergency report, classify it into one of the available incident types, provide a confidence score, and list the key factors.

        Use the following examples to guide your decision-making process.
        
        ---
        EXAMPLES:

        Medical Emergencies (Cardiovascular & Respiratory):
        - Caller Report: "My husband just collapsed! He was clutching his chest and now he's not breathing. Please hurry!" -> Expected Incident Type: Cardiac Arrest
        - Caller Report: "I'm having a really hard time breathing. It feels like my chest is tightening up and I can't get any air. I have a history of asthma." -> Expected Incident Type: Breathing Problems
        - Caller Report: "My mother is complaining of a crushing pain in her chest, and it's going down her left arm. She's pale and sweaty." -> Expected Incident Type: Heart Attack
        - Caller Report: "My grandfather's speech is suddenly slurred, and the right side of his face is drooping. He can't lift his right arm at all." -> Expected Incident Type: Stroke
        - Caller Report: "Help! My baby is choking on a piece of food. He's turning blue!" -> Expected Incident Type: Choking

        Trauma & Injury:
        - Caller Report: "There was just a multi-car pile-up on the NICE Ring Road near the Kanakapura exit. At least 5 cars are involved, and multiple people are injured." -> Expected Incident Type: Mass Casualty Incident
        - Caller Report: "A construction worker fell from the third story of the building site on MG Road. He's unconscious and bleeding from his head." -> Expected Incident Type: Major Trauma
        - Caller Report: "My wife slipped in the kitchen and her leg is bent at a really strange angle. She's in incredible pain and can't move it." -> Expected Incident Type: Fracture
        - Caller Report: "Someone just got attacked outside the bar on Church Street. He's on the ground and bleeding a lot from a cut on his arm." -> Expected Incident Type: Assault
        - Caller Report: "I was cooking and spilled a pot of boiling water all over my arm. The skin is red and blistering, and the pain is terrible." -> Expected Incident Type: Burns
        - Caller Report: "My friend was in a bike accident and has a deep cut on his leg. We've applied pressure but it won't stop bleeding." -> Expected Incident Type: Bleeding/Hemorrhage
        - Caller Report: "My elderly father fell down the stairs. He's awake but very confused and says his back hurts." -> Expected Incident Type: Fall

        Environmental & Hazardous Incidents:
        - Caller Report: "There's a huge fire at the garment factory in Peenya Industrial Area. I can see black smoke billowing out of the windows." -> Expected Incident Type: Fire
        - Caller Report: "A tanker truck has overturned on the highway and it's leaking some kind of chemical. There's a strong, foul smell in the air." -> Expected Incident Type: Hazardous Material Spill
        - Caller Report: "We've had a carbon monoxide alarm going off for the past 10 minutes. My whole family feels dizzy and nauseous." -> Expected Incident Type: Carbon Monoxide Poisoning
        - Caller Report: "I can smell gas very strongly in my apartment building's basement. I think there might be a leak." -> Expected Incident Type: Gas Leak
        - Caller Report: "The old building next door just collapsed! I heard a loud crash and now there's dust everywhere. I think people were inside." -> Expected Incident Type: Structural Collapse

        Medical (General):
        - Caller Report: "My son was stung by a bee and now his face and throat are swelling up. He's having trouble breathing." -> Expected Incident Type: Allergic Reaction
        - Caller Report: "My roommate has been having seizures for the last five minutes and hasn't stopped. He's shaking all over." -> Expected Incident Type: Seizure
        - Caller Report: "My daughter is a diabetic and she's become very confused and drowsy. Her blood sugar is extremely low." -> Expected Incident Type: Diabetic Emergency
        - Caller Report: "I found my friend passed out. He's breathing but I can't wake him up. There are empty pill bottles next to him." -> Expected Incident Type: Drug Overdose
        - Caller Report: "My wife is 9 months pregnant and her water just broke. The contractions are coming very fast now." -> Expected Incident Type: Maternity/Childbirth
        - Caller Report: "A stray dog just bit my son on the leg. The skin is broken and it's bleeding." -> Expected Incident Type: Animal Bite
        - Caller Report: "My husband has a terrible pain in his stomach. He's doubled over and feels like he's going to be sick." -> Expected Incident Type: Abdominal Pain
        - Caller Report: "I've been working outside all day in the heat and now I feel extremely dizzy, my skin is hot but I'm not sweating." -> Expected Incident Type: Heat Stroke/Exhaustion
        - Caller Report: "My friend is unconscious but still breathing. We were at a party and he drank way too much." -> Expected Incident Type: Unconscious/Unresponsive
        - Caller Report: "I think my brother has sepsis. He has a high fever, a fast heart rate, and is very confused." -> Expected Incident Type: Sepsis
        - Caller Report: "An electrician was working on a power line and got a shock. He was thrown back and is now on the ground." -> Expected Incident Type: Electrocution
        - Caller Report: "My friend took some medication he wasn't supposed to and now he's acting very strange and throwing up." -> Expected Incident Type: Poisoning
        - Caller Report: "The river is rising fast and the water is already entering our house. We are trapped on the second floor." -> Expected Incident Type: Flood
        - Caller Report: "There's been a bad accident at the factory. A worker's arm is caught in a machine." -> Expected Incident Type: Industrial Accident
        - Caller Report: "A child fell into the pool and was underwater for a minute. We pulled him out and he's coughing up water but he's breathing." -> Expected Incident Type: Drowning/Near Drowning
        - Caller Report: "We've been out in the cold for hours and my friend is shivering uncontrollably and seems very confused." -> Expected Incident Type: Hypothermia

        Lower Acuity & Miscellaneous:
        - Caller Report: "I have a terrible migraine and I can't see properly. The pain is unbearable." -> Expected Incident Type: Headache/Migraine
        - Caller Report: "I'm having a severe panic attack. My heart is racing and I feel like I'm going to die. I need someone to talk to." -> Expected Incident Type: Mental Health Crisis
        - Caller Report: "I was playing football and twisted my ankle. It's swollen and I can't put any weight on it." -> Expected Incident Type: Minor Injury
        - Caller Report: "My child has a very high fever, over 104 degrees, and he's not responding to medicine." -> Expected Incident Type: Fever
        - Caller Report: "I accidentally splashed some cleaning chemical in my eye and it's burning badly." -> Expected Incident Type: Eye Injury
        - Caller Report: "My nose has been bleeding for 20 minutes and it won't stop, no matter what I do." -> Expected Incident Type: Nosebleed
        - Caller Report: "I'm feeling extremely dizzy and the room is spinning. I can't stand up without falling over." -> Expected Incident Type: Dizziness/Vertigo
        - Caller Report: "I'm experiencing a sharp, debilitating pain in my lower back and I'm unable to move." -> Expected Incident Type: Back Pain
        - Caller Report: "My friend just fainted at the mall. He was standing one moment and on the floor the next. He's waking up now but seems dazed." -> Expected Incident Type: Fainting/Syncope
        - Caller Report: "My toddler swallowed a small toy piece. He seems to be breathing okay but I'm worried." -> Expected Incident Type: Ingestion of Foreign Object
        - Caller Report: "I was hiking in Nandi Hills and got bitten by a snake. I don't know if it's venomous." -> Expected Incident Type: Snake Bite
        - Caller Report: "I don't really know what's wrong. I just feel extremely weak and unwell all over." -> Expected Incident Type: Unknown Medical Emergency
        - Caller Report: "I cut my hand badly while chopping vegetables. It's a deep gash and I think I might need stitches." -> Expected Incident Type: Laceration/Cut
        - Caller Report: "My leg hurts so much I can't describe it. Nothing happened, it just started hurting out of nowhere." -> Expected Incident Type: Severe Pain
        - Caller Report: "My child's plastic bag got stuck over his head for a few seconds. He's okay now but he was gasping for air." -> Expected Incident Type: Suffocation

        Disaster Incidents:
        - Caller Report: "There was a small kitchen fire. We put it out with an extinguisher, but the kitchen is full of smoke and we're not sure if it's safe." -> Expected Incident Type: Fire
        - Caller Report: "A bus just overturned on the highway, and there are dozens of injured passengers trapped inside." -> Expected Incident Type: Mass Transport Crash
        - Caller Report: "The hillside behind our house collapsed, and my neighbor’s car is buried. I think people are trapped!" -> Expected Incident Type: Landslide / Mudslide
        - Caller Report: "We heard a loud explosion at the chemical plant. People are coughing and there’s a strong chemical smell." -> Expected Incident Type: Chemical / Hazmat Incident
        - Caller Report: "A small plane skidded off the runway, there’s smoke, and people are screaming!" -> Expected Incident Type: Airport Crash
        - Caller Report: "We’re on a mountain trail and saw an avalanche bury several skiers. We can’t see them anymore!" -> Expected Incident Type: Avalanche
        - Caller Report: "The bridge over the river just collapsed with several cars on it! People are in the water!" -> Expected Incident Type: Bridge Collapse
        - Caller Report: "An apartment building next door collapsed after a loud bang. We can hear people screaming under debris!" -> Expected Incident Type: Building Collapse
        - Caller Report: "There’s a dam upstream that just burst. Water is rushing down, and homes are already flooding!" -> Expected Incident Type: Dam Failure / Levee Breach
        - Caller Report: "The hospital says they’ve seen hundreds of patients with severe diarrhea and vomiting after a banquet." -> Expected Incident Type: Mass Food Poisoning
        - Caller Report: "There’s gunfire inside the mall. Multiple people are down, and others are running everywhere!" -> Expected Incident Type: Mass Shooting
        - Caller Report: "Our ferry hit something and is taking on water fast. People are jumping overboard!" -> Expected Incident Type: Ferry/Ship Sinking
        - Caller Report: "The entire neighborhood is underwater after last night’s storm. People are trapped in their houses!" -> Expected Incident Type: Large-Scale Flood
        - Caller Report: "We just felt a huge earthquake. Buildings are cracked, and there are people trapped under rubble!" -> Expected Incident Type: Major Earthquake
        - Caller Report: "My grandmother fainted after days without food or water. There are no supplies in our village." -> Expected Incident Type: Drought / Famine
        - Caller Report: "There’s thick smoke coming from a factory warehouse, and we can hear small explosions inside." -> Expected Incident Type: Industrial Fire
        - Caller Report: "We were hiking near the volcano when it suddenly erupted. The sky is dark, and ash is falling heavily!" -> Expected Incident Type: Volcanic Eruption
        - Caller Report: "My father is coughing and his skin is burning after opening a strange container at work." -> Expected Incident Type: Chemical / Hazmat Incident
        - Caller Report: "A cruise ship is listing heavily near the coast, and passengers are screaming for help." -> Expected Incident Type: Ferry/Ship Sinking
        - Caller Report: "People are collapsing from heat outside. Several are unconscious at the bus stop!" -> Expected Incident Type: Heatwave / Extreme Heat
        - Caller Report: "Our street is completely blocked by snow. My neighbor hasn’t been seen in days, and their car is buried." -> Expected Incident Type: Severe Winter Storm
        - Caller Report: "There’s a fire racing through the forest near our home. The smoke is so thick we can’t breathe!" -> Expected Incident Type: Wildfire / Forest Fire
        - Caller Report: "Several miners haven’t come out of the shaft, and there’s been a cave-in underground!" -> Expected Incident Type: Mine Collapse
        - Caller Report: "Everyone at the concert is running! I think people are getting trampled. Someone’s not breathing!" -> Expected Incident Type: Stampede / Crowd Crush
        - Caller Report: "There’s a strange humming noise coming from a damaged nuclear plant. Workers are evacuating fast." -> Expected Incident Type: Nuclear/Radiological Incident
        - Caller Report: "People are lying unconscious at the park, and others are vomiting after drinking from a public fountain!" -> Expected Incident Type: Mass Food Poisoning
        - Caller Report: "A tornado ripped through town. Buildings are destroyed, and cars are flipped over!" -> Expected Incident Type: Hurricane / Cyclone
        - Caller Report: "There are multiple cars piled up on the freeway, and some are on fire. We need help!" -> Expected Incident Type: Mass Transport Crash
        - Caller Report: "The river overflowed its banks overnight. Families are trapped on their rooftops." -> Expected Incident Type: Large-Scale Flood
        - Caller Report: "There’s a strange smell in the subway, and several passengers have collapsed." -> Expected Incident Type: Chemical / Hazmat Incident
        - Caller Report: "A giant tree fell on a group of hikers during a landslide. They’re pinned under debris!" -> Expected Incident Type: Landslide / Mudslide
        - Caller Report: "There’s smoke pouring out of a nursing home, and elderly people are inside!" -> Expected Incident Type: Fire
        - Caller Report: "A jetliner just crash-landed near the highway. There’s fire, and people are screaming!" -> Expected Incident Type: Airport Crash
        - Caller Report: "A tanker truck overturned on the highway and is leaking something that burns our throats!" -> Expected Incident Type: Chemical / Hazmat Incident
        - Caller Report: "A volcano just erupted near our town. Lava is heading this way fast!" -> Expected Incident Type: Volcanic Eruption
        - Caller Report: "We’re stuck on our roof. The water is rising quickly, and rescue boats aren’t here yet!" -> Expected Incident Type: Dam Failure / Levee Breach
        - Caller Report: "My baby has a high fever and trouble breathing after drinking formula. Other babies are sick too!" -> Expected Incident Type: Mass Food Poisoning
        - Caller Report: "People are fighting at the evacuation center. The police need backup!" -> Expected Incident Type: Stampede / Crowd Control
        - Caller Report: "An avalanche just wiped out the ski lift area. There’s no sign of the skiers!" -> Expected Incident Type: Avalanche
        - Caller Report: "A warehouse fire spread to nearby houses, and there are still people trapped inside." -> Expected Incident Type: Fire
        - Caller Report: "A neighborhood gas leak caused a house explosion. There are injured people everywhere!" -> Expected Incident Type: Industrial Fire
        - Caller Report: "A fishing boat sank offshore. Survivors are clinging to debris!" -> Expected Incident Type: Ferry/Ship Sinking
        - Caller Report: "A car crashed into a bridge support, and the entire bridge section fell onto traffic below!" -> Expected Incident Type: Bridge Collapse
        - Caller Report: "Multiple people collapsed in a crowded subway station. We think it’s a gas attack!" -> Expected Incident Type: Chemical / Hazmat Incident
        - Caller Report: "The hospital is overwhelmed. There are hundreds of people with flu-like symptoms." -> Expected Incident Type: Pandemic (Severe Wave)
        - Caller Report: "We’re stuck in our cars overnight in the snowstorm. People are running out of fuel!" -> Expected Incident Type: Severe Winter Storm
        - Caller Report: "An amusement park ride collapsed. Many are injured, and some are trapped under the ride!" -> Expected Incident Type: Building Collapse
        - Caller Report: "A commuter train derailed in the tunnel. It’s filling with smoke!" -> Expected Incident Type: Mass Transport Crash
        ---

        From the emergency report below, perform three tasks based on the examples provided:
        1.  Choose the most likely incident type from the available list.
        2.  Provide a confidence score for your choice (as a percentage, e.g., "95%").
        3.  List the top 3 key phrases from the report that most influenced your decision.

        Report to Analyze:
        "{{report}}"

        Available Incident Types: [${incidentNameList}]
    `,
});

// Define the main Genkit flow for analyzing reports.
const analyzeReportFlow = ai.defineFlow(
  {
    name: 'analyzeReportFlow',
    inputSchema: AnalyzeReportInputSchema,
    outputSchema: AnalyzeReportOutputSchema,
  },
  async (input) => {
    let reportToAnalyze = input.report;
    let translatedReport: string | undefined = undefined;

    // Check if the report is in a language other than English.
    if (input.language !== 'en-IN') {
        // If not English, call the translation prompt first.
        const translationResponse = await translationPrompt({ report: input.report });
        translatedReport = translationResponse.text;
        reportToAnalyze = translatedReport;
    }

    // Call the main analysis prompt with the (potentially translated) report.
    const { output } = await analysisPrompt({ report: reportToAnalyze });
    if (!output) {
        throw new Error('Analysis prompt failed to produce output.');
    }
    
    // Return the structured output, including the translated report if it exists.
    return {
        ...output,
        translatedReport,
    };
  }
);
