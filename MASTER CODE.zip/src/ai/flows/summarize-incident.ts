'use server';

/**
 * @fileOverview Summarizes incident reports using GenAI.
 *
 * - summarizeIncident - A function that summarizes an incident report.
 * - SummarizeIncidentInput - The input type for the summarizeIncident function.
 * - SummarizeIncidentOutput - The return type for the summarizeIncident function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeIncidentInputSchema = z.object({
  report: z.string().describe('The full incident report text.'),
});
export type SummarizeIncidentInput = z.infer<typeof SummarizeIncidentInputSchema>;

const SummarizeIncidentOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the incident report in bullet points.'),
});
export type SummarizeIncidentOutput = z.infer<typeof SummarizeIncidentOutputSchema>;

export async function summarizeIncident(input: SummarizeIncidentInput): Promise<SummarizeIncidentOutput> {
  return summarizeIncidentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeIncidentPrompt',
  input: {schema: SummarizeIncidentInputSchema},
  output: {schema: SummarizeIncidentOutputSchema},
  prompt: `You are an AI assistant helping emergency dispatchers quickly understand incident reports.
  Summarize the following incident report into a few bullet points, focusing on the most critical information.

Incident Report:
{{{report}}}`,
});

const summarizeIncidentFlow = ai.defineFlow(
  {
    name: 'summarizeIncidentFlow',
    inputSchema: SummarizeIncidentInputSchema,
    outputSchema: SummarizeIncidentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
