'use server';

/**
 * @fileOverview Recommends a dispatch package for a given incident type.
 *
 * - getDispatchPackage - A function that returns a recommended set of units.
 * - GetDispatchPackageInput - The input type for the getDispatchPackage function.
 * - GetDispatchPackageOutput - The return type for the getDispatchPackage function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GetDispatchPackageInputSchema = z.object({
  incidentType: z.string().describe('The type of incident.'),
});
export type GetDispatchPackageInput = z.infer<typeof GetDispatchPackageInputSchema>;

const GetDispatchPackageOutputSchema = z.object({
  dispatchPackage: z
    .array(
      z.object({
        unitType: z.string().describe('The type of unit to dispatch (e.g., "Type C (ALS)").'),
        quantity: z.number().describe('The number of units of this type to dispatch.'),
      })
    )
    .describe('An array of objects representing the recommended dispatch package.'),
});
export type GetDispatchPackageOutput = z.infer<typeof GetDispatchPackageOutputSchema>;

export async function getDispatchPackage(input: GetDispatchPackageInput): Promise<GetDispatchPackageOutput> {
  return getDispatchPackageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'getDispatchPackagePrompt',
  input: { schema: GetDispatchPackageInputSchema },
  output: { schema: GetDispatchPackageOutputSchema },
  prompt: `
        Based on a "{{incidentType}}" in a dense urban area, recommend an optimal initial dispatch package.
        List the unit types and quantities.
    `,
});

const getDispatchPackageFlow = ai.defineFlow(
  {
    name: 'getDispatchPackageFlow',
    inputSchema: GetDispatchPackageInputSchema,
    outputSchema: GetDispatchPackageOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
