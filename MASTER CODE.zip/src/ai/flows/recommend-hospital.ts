'use server';

/**
 * @fileOverview Recommends the best hospital for an incident.
 *
 * - recommendHospital - A function that returns the optimal hospital.
 * - RecommendHospitalInput - The input type for the function.
 * - RecommendHospitalOutput - The return type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { getTrafficReport } from './get-traffic-report';

const HospitalInfoSchema = z.object({
  name: z.string(),
  capabilities: z.array(z.string()),
  beds: z.string().describe('Bed availability status (e.g., "High", "Medium", "Low").'),
  distance: z.string().describe('Distance from the incident in kilometers.'),
});

const RecommendHospitalInputSchema = z.object({
  incidentType: z.string().describe('The type of incident.'),
  requiredCapability: z.string().describe('The specific medical capability required for this incident type.'),
  hospitals: z.array(HospitalInfoSchema).describe('A list of nearby hospitals with their details.'),
});
export type RecommendHospitalInput = z.infer<typeof RecommendHospitalInputSchema>;

const RecommendHospitalOutputSchema = z.object({
  hospitalName: z.string().describe('The name of the recommended hospital.'),
  reasoning: z.string().describe('A brief explanation for why this hospital was chosen.'),
});
export type RecommendHospitalOutput = z.infer<typeof RecommendHospitalOutputSchema>;

export async function recommendHospital(input: RecommendHospitalInput): Promise<RecommendHospitalOutput> {
  return recommendHospitalFlow(input);
}

const prompt = ai.definePrompt({
  name: 'recommendHospitalPrompt',
  input: { schema: RecommendHospitalInputSchema.extend({ traffic: z.string() }) },
  output: { schema: RecommendHospitalOutputSchema },
  prompt: `
        You are an expert AI assistant for an emergency dispatch command center.
        Your task is to recommend the best hospital for a patient based on the following data.

        Incident Details:
        - Type: {{incidentType}}
        - Required Medical Capability: {{requiredCapability}}

        Live Traffic Conditions:
        - {{traffic}}

        Nearby Hospitals:
        {{#each hospitals}}
        - Name: {{name}}
          Capabilities: {{join capabilities ", "}}
          Bed Availability: {{beds}}
          Distance: {{distance}}
        {{/each}}

        Decision Factors:
        1.  **Capability Match**: The hospital MUST have the "{{requiredCapability}}" capability. This is the most important factor.
        2.  **Bed Availability**: Prioritize hospitals with "Low" or "Medium" bed occupancy over "High".
        3.  **Distance & Traffic**: Consider the distance and the current traffic report to estimate the fastest arrival time. A slightly farther hospital with clear traffic may be better than a closer one through heavy congestion.

        Based on these factors, choose the single best hospital and provide a brief reasoning for your choice.
    `,
});

const recommendHospitalFlow = ai.defineFlow(
  {
    name: 'recommendHospitalFlow',
    inputSchema: RecommendHospitalInputSchema,
    outputSchema: RecommendHospitalOutputSchema,
  },
  async (input) => {
    const trafficReport = await getTrafficReport();
    const { output } = await prompt({ ...input, traffic: trafficReport.report });
    return output!;
  }
);
