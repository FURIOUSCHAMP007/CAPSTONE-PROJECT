'use server';

/**
 * @fileOverview Fetches a live traffic report summary.
 *
 * - getTrafficReport - A function that returns a traffic summary.
 * - GetTrafficReportOutput - The return type for the getTrafficReport function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GetTrafficReportOutputSchema = z.object({
  report: z.string().describe('A one-sentence summary of the current live traffic conditions.'),
});
export type GetTrafficReportOutput = z.infer<typeof GetTrafficReportOutputSchema>;

export async function getTrafficReport(): Promise<GetTrafficReportOutput> {
  return getTrafficReportFlow();
}

const prompt = ai.definePrompt({
  name: 'getTrafficReportPrompt',
  output: { schema: GetTrafficReportOutputSchema },
  prompt: `Provide a brief, one-sentence summary of the current live traffic condition in Bengaluru, India. It's Saturday evening at 5:48 PM IST. Mention one or two key congested roads if possible.`,
});

const getTrafficReportFlow = ai.defineFlow(
  {
    name: 'getTrafficReportFlow',
    outputSchema: GetTrafficReportOutputSchema,
  },
  async () => {
    const { output } = await prompt();
    return output!;
  }
);
