'use server';

/**
 * @fileOverview Generates a comprehensive post-incident debrief analysis.
 *
 * - debriefIncident - A function that creates a debrief report.
 * - DebriefIncidentInput - The input type for the function.
 * - DebriefIncidentOutput - The return type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const DebriefIncidentInputSchema = z.object({
  id: z.string(),
  type: z.string(),
  startTime: z.string(),
  endTime: z.string(),
  unitId: z.string(),
  callerReport: z.string(),
  logs: z.array(z.string()),
});
export type DebriefIncidentInput = z.infer<typeof DebriefIncidentInputSchema>;

const DebriefIncidentOutputSchema = z.object({
  title: z.string().describe('A concise title for the incident debrief.'),
  summary: z.string().describe('A one-paragraph summary of the entire incident from start to finish.'),
  timeline: z.array(z.object({
    time: z.string().describe('The timestamp of the event.'),
    description: z.string().describe('A description of what happened at this time.'),
  })).describe('A chronological list of key events during the incident.'),
  analysis: z.object({
    whatWentWell: z.array(z.string()).describe('A list of 2-3 points on what went well during the response.'),
    areasForImprovement: z.array(z.string()).describe('A list of 2-3 points on areas that could be improved for future incidents of this type.'),
  }),
  keyTakeaway: z.string().describe('A single, crucial takeaway or learning from this incident that can be applied to future training or operations.'),
});
export type DebriefIncidentOutput = z.infer<typeof DebriefIncidentOutputSchema>;

export async function debriefIncident(input: DebriefIncidentInput): Promise<DebriefIncidentOutput> {
  return debriefIncidentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'debriefIncidentPrompt',
  input: { schema: DebriefIncidentInputSchema },
  output: { schema: DebriefIncidentOutputSchema },
  prompt: `
        You are an AI assistant for an emergency response command center. Your task is to conduct a post-incident debrief.
        Analyze the provided incident data to generate a structured debriefing report.

        Incident Data:
        - Incident ID: {{id}}
        - Incident Type: {{type}}
        - Start Time: {{startTime}}
        - End Time: {{endTime}}
        - Responding Unit(s): {{unitId}}
        - Initial Caller Report: "{{callerReport}}"
        - System Log Entries:
        {{#each logs}}
        - {{this}}
        {{/each}}

        Based on this data, generate a complete debriefing report. Construct a plausible but detailed timeline of events.
        Your analysis should be objective, focusing on operational effectiveness and identifying learning opportunities.
    `,
});

const debriefIncidentFlow = ai.defineFlow(
  {
    name: 'debriefIncidentFlow',
    inputSchema: DebriefIncidentInputSchema,
    outputSchema: DebriefIncidentOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
