import MapLayout from "@/components/map-layout";

export default function Home() {
  return (
    <main className="h-screen w-screen overflow-hidden">
      <MapLayout />
    </main>
  );
}
