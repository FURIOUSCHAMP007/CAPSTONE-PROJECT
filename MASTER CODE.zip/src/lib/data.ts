
import type { Incident, Responder, Hospital, IncidentType, FleetDescription, HospitalCapability } from './types';

// Zone Coordinates for Bengaluru
const zones = {
    Central: { lat: 12.9716, lng: 77.5946 },
    South:   { lat: 12.9155, lng: 77.5855 },
    West:    { lat: 12.9791, lng: 77.5517 },
    North:   { lat: 13.0359, lng: 77.5971 },
    East:    { lat: 12.9719, lng: 77.6379 },
    Airport: { lat: 13.1989, lng: 77.7068 },
    ElectronicCity: { lat: 12.8452, lng: 77.6602 },
    Yelahanka: { lat: 13.1006, lng: 77.5963 }
};

const vehicleTypes = [
    'Type A (Basic)',
    'Type B (BLS)',
    'Type C (ALS)',
    'Type D (ICU)',
    'Type E (Neonatal)',
    'Type F (Disaster)',
    'Air Ambulance',
];

const generateResponders = (): Responder[] => {
    const responders: Responder[] = [];
    const zonePrefixes = {
        Central: 'C',
        South: 'S',
        West: 'W',
        North: 'N',
        East: 'E',
        Airport: 'A',
        ElectronicCity: 'EC',
        Yelahanka: 'Y'
    };
    const typeSuffixes: {[key: string]: string} = {
        'Type A (Basic)': 'AMB-A',
        'Type B (BLS)': 'AMB-B',
        'Type C (ALS)': 'AMB-C',
        'Type D (ICU)': 'AMB-D',
        'Type E (Neonatal)': 'AMB-E',
        'Type F (Disaster)': 'MCV-F',
        'Air Ambulance': 'AIR',
    };

    Object.entries(zones).forEach(([zoneName, coords]) => {
        const prefix = zonePrefixes[zoneName as keyof typeof zonePrefixes];

        // Add one of each specialized ambulance type
        vehicleTypes.forEach(type => {
            responders.push({
                id: `${prefix}-${typeSuffixes[type]}01`,
                type: type,
                lat: coords.lat + (Math.random() - 0.5) * 0.05,
                lng: coords.lng + (Math.random() - 0.5) * 0.05,
                status: 'Available',
                incidentId: null,
                baseLocation: { lat: coords.lat, lng: coords.lng }
            });
        });
        
        // Add 10 fire engines
        for (let i = 1; i <= 10; i++) {
            const paddedId = i.toString().padStart(2, '0');
            responders.push({
                id: `${prefix}-ENG${paddedId}`,
                type: 'Fire Engine',
                lat: coords.lat + (Math.random() - 0.5) * 0.05,
                lng: coords.lng + (Math.random() - 0.5) * 0.05,
                status: 'Available',
                incidentId: null,
                baseLocation: { lat: coords.lat, lng: coords.lng }
            });
        }

        // Add 10 police cars
        for (let i = 1; i <= 10; i++) {
            const paddedId = i.toString().padStart(2, '0');
            responders.push({
                id: `${prefix}-POL${paddedId}`,
                type: 'Police Car',
                lat: coords.lat + (Math.random() - 0.5) * 0.05,
                lng: coords.lng + (Math.random() - 0.5) * 0.05,
                status: 'Available',
                incidentId: null,
                baseLocation: { lat: coords.lat, lng: coords.lng }
            });
        }
    });

    return responders;
};

export const initialResponders: Responder[] = generateResponders();

export const incidentTypes: IncidentType[] = [
    { name: 'Abdominal Pain', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Low', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Allergic Reaction', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Animal Bite', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Assault', type: 'Crime', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Back Pain', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Low', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Bleeding/Hemorrhage', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Breathing Problems', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Burns', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Carbon Monoxide Poisoning', type: 'Medical', recommendedUnit: 'Type D (ICU)', description: 'ICU-on-wheels for critical patients.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Cardiac Arrest', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'Critical', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Chest Pain', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Choking', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Diabetic Emergency', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Dizziness/Vertigo', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Low', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Drowning/Near Drowning', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'Critical', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Drug Overdose', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Electrocution', type: 'Medical', recommendedUnit: 'Type D (ICU)', description: 'ICU-on-wheels for critical patients.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Eye Injury', type: 'Medical', recommendedUnit: 'Type A (Basic)', description: 'Transport of non-emergency/walking wounded.', severity: 'Low', hospitalCapability: 'Basic', requiresPackage: false },
    { name: 'Fainting/Syncope', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Fall', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Fever', type: 'Medical', recommendedUnit: 'Type A (Basic)', description: 'Transport of non-emergency/walking wounded.', severity: 'Low', hospitalCapability: 'Basic', requiresPackage: false },
    { name: 'Fire', type: 'Fire', recommendedUnit: 'Fire Engine', description: 'Fire suppression and rescue operations.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Flood', type: 'Fire', recommendedUnit: 'Fire Engine', description: 'Water rescue and evacuation support.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Fracture', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Gas Leak', type: 'Fire', recommendedUnit: 'Fire Engine', description: 'Hazardous material containment.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Hazardous Material Spill', type: 'Fire', recommendedUnit: 'Fire Engine', description: 'Hazardous material containment and cleanup.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: true },
    { name: 'Headache/Migraine', type: 'Medical', recommendedUnit: 'Type A (Basic)', description: 'Transport of non-emergency/walking wounded.', severity: 'Low', hospitalCapability: 'Basic', requiresPackage: false },
    { name: 'Heart Attack', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'Critical', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Heat Stroke/Exhaustion', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Hypothermia', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Industrial Accident', type: 'Medical', recommendedUnit: 'Type D (ICU)', description: 'ICU-on-wheels for critical patients.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: true },
    { name: 'Ingestion of Foreign Object', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Laceration/Cut', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Major Trauma', type: 'Medical', recommendedUnit: 'Type D (ICU)', description: 'ICU-on-wheels for critical patients.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Mass Casualty Incident', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Multiple patient transport, triage zone on wheels.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Maternity/Childbirth', type: 'Medical', recommendedUnit: 'Type E (Neonatal)', description: 'For transporting newborns needing intensive care.', severity: 'High', hospitalCapability: 'Maternity', requiresPackage: false },
    { name: 'Mental Health Crisis', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Minor Injury', type: 'Medical', recommendedUnit: 'Type A (Basic)', description: 'Transport of non-emergency/walking wounded.', severity: 'Low', hospitalCapability: 'Basic', requiresPackage: false },
    { name: 'Nosebleed', type: 'Medical', recommendedUnit: 'Type A (Basic)', description: 'Transport of non-emergency/walking wounded.', severity: 'Low', hospitalCapability: 'Basic', requiresPackage: false },
    { name: 'Poisoning', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Seizure', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Sepsis', type: 'Medical', recommendedUnit: 'Type D (ICU)', description: 'ICU-on-wheels for critical patients.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: false },
    { name: 'Severe Pain', type: 'Medical', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Snake Bite', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Stroke', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'Critical', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Structural Collapse', type: 'Fire', recommendedUnit: 'Fire Engine', description: 'Urban search and rescue operations.', severity: 'Critical', hospitalCapability: 'ICU', requiresPackage: true },
    { name: 'Suffocation', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Traffic Accident', type: 'Crime', recommendedUnit: 'Type B (BLS)', description: 'Non-life-threatening but needs medical attention.', severity: 'Medium', hospitalCapability: 'BLS', requiresPackage: false },
    { name: 'Unconscious/Unresponsive', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    { name: 'Unknown Medical Emergency', type: 'Medical', recommendedUnit: 'Type C (ALS)', description: 'Life-threatening emergencies needing intervention.', severity: 'High', hospitalCapability: 'ALS', requiresPackage: false },
    // New Disaster Types
    { name: 'Mass Transport Crash', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Large-scale vehicle crash with multiple victims.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Landslide / Mudslide', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Geological event with potential for buried victims.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Chemical / Hazmat Incident', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Hazardous material release requiring specialized response.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Airport Crash', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Aircraft incident requiring a large-scale emergency response.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Avalanche', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Snow slide with high potential for buried victims.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Bridge Collapse', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Structural failure of a bridge with vehicles or people.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Building Collapse', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Structural failure of a building, trapping occupants.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Dam Failure / Levee Breach', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Catastrophic flooding from a failed water barrier.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Mass Food Poisoning', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Widespread illness from contaminated food source.', severity: 'High', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Mass Shooting', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Active violence incident with multiple casualties.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Ferry/Ship Sinking', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Maritime disaster requiring mass rescue.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Large-Scale Flood', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Widespread flooding affecting a large area.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Major Earthquake', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Seismic event causing widespread damage and casualties.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Drought / Famine', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Humanitarian crisis due to lack of food and water.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Industrial Fire', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Large fire at an industrial facility, possibly with hazmat.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Volcanic Eruption', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Geological event with lava flows, ash, and gas.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Heatwave / Extreme Heat', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Widespread heat-related illnesses and deaths.', severity: 'High', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Severe Winter Storm', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Major snow or ice storm causing widespread disruption.', severity: 'High', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Wildfire / Forest Fire', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Uncontrolled fire in a wildland area.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Mine Collapse', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Collapse of a mine, trapping workers.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Stampede / Crowd Crush', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Uncontrolled crowd movement causing injuries/fatalities.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Nuclear/Radiological Incident', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Release of radioactive materials.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Hurricane / Cyclone', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Severe tropical storm with high winds and flooding.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Stampede / Crowd Control', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Uncontrolled crowd movement requiring intervention.', severity: 'High', hospitalCapability: 'Disaster', requiresPackage: true },
    { name: 'Pandemic (Severe Wave)', type: 'Disaster', recommendedUnit: 'Type F (Disaster)', description: 'Widespread infectious disease outbreak overwhelming health systems.', severity: 'Critical', hospitalCapability: 'Disaster', requiresPackage: true },
].sort((a, b) => a.name.localeCompare(b.name));

export const fleetDescriptions: FleetDescription[] = [
    { name: 'Type A (Basic Ambulance)', imageKey: 'basicAmbulance', purpose: 'For non-emergency patient transport and minor injuries. The most basic level of care.', staff: 'Driver + Attendant', equipment: 'Basic first aid kit, stretcher, oxygen cylinder.' },
    { name: 'Type B (Basic Life Support - BLS)', imageKey: 'blsAmbulance', purpose: 'For patients with non-life-threatening conditions who still require medical monitoring.', staff: 'EMT or Paramedic', equipment: 'Oxygen delivery systems, basic vital signs monitor, splints, bandages.' },
    { name: 'Type C (Advanced Life Support - ALS)', imageKey: 'alsAmbulance', purpose: 'For patients in life-threatening situations requiring advanced medical intervention en route.', staff: 'Paramedic/Doctor + EMT', equipment: 'Cardiac monitor/defibrillator, IV supplies, advanced airway equipment, emergency medications.' },
    { name: 'Type D (Critical Care/ICU Ambulance)', imageKey: 'icuAmbulance', purpose: 'Essentially an ICU on wheels, designed for transporting critically ill patients between facilities.', staff: 'Doctor + Nurse + Paramedic', equipment: 'ICU-grade monitor, portable ventilator, multiple infusion pumps, advanced resuscitation gear.' },
    { name: 'Type E (Neonatal Ambulance)', imageKey: 'neonatalAmbulance', purpose: 'A specialized mobile NICU for transporting critically ill newborns and infants.', staff: 'Pediatrician + Neonatal nurse', equipment: 'Transport incubator, neonatal ventilator, specialized monitoring equipment for infants.' },
    { name: 'Type F (Disaster Response)', imageKey: 'disasterResponse', purpose: 'A large vehicle for handling Mass Casualty Incidents (MCIs) and acting as a mobile triage zone.', staff: 'EMTs or Disaster Medical Team', equipment: 'Modular stretcher systems, bulk trauma and first aid supplies, triage tags, communication systems.' },
    { name: 'Air Ambulance', imageKey: 'airAmbulance', purpose: 'For rapid transport from remote, inaccessible areas or for long-distance critical transfers.', staff: 'Flight nurse + Critical care specialist', equipment: 'Compact versions of ALS/ICU equipment, specialized air evacuation gear.' },
    { name: 'Fire Engine', imageKey: 'fireEngine', purpose: 'For fire suppression, vehicle extrication, and providing initial medical response at accident scenes.', staff: 'Firefighters (often EMT-trained)', equipment: 'Water pumps, hoses, ladders, Jaws of Life, basic medical and trauma supplies.' },
    { name: 'Police Car', imageKey: 'policeCar', purpose: 'For securing incident scenes, traffic control, and law enforcement response.', staff: 'Police Officers', equipment: 'Communication systems, first aid kit, traffic cones.' },
];

export const initialHospitals: Hospital[] = [
    { name: "Manipal Hospital, Old Airport Road", location: { lat: 12.9599, lng: 77.6607 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "98, HAL Old Airport Rd, Kodihalli, Bengaluru", phone: "+91 1800 102 4647", beds: "High" },
    { name: "Fortis Hospital, Bannerghatta Road", location: { lat: 12.8943, lng: 77.5971 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "154, 9, Bannerghatta Main Rd, Panduranga Nagar, Bengaluru", phone: "+91 96633 67253", beds: "Medium" },
    { name: "Apollo Cradle & Children's Hospital", location: { lat: 12.9284, lng: 77.6293 }, capabilities: ["Maternity", "Pediatrics", "Neonatal ICU"], address: "58, 18th Main Rd, 6th Block, Koramangala, Bengaluru", phone: "+91 98216 56657", beds: "High" },
    { name: "Narayana Institute of Cardiac Sciences", location: { lat: 12.8252, lng: 77.6698 }, capabilities: ["Specialized Cardiac Care (Basic, BLS, ALS, ICU, Cardiac Surgery)"], address: "258/A, Hosur Rd, Bommasandra Industrial Area, Bengaluru", phone: "+91 80675 06870", beds: "High" },
    { name: "Victoria Hospital Trauma Care Centre", location: { lat: 12.9644, lng: 77.5724 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Disaster"], address: "New Tharagupet, Bengaluru, Karnataka 560002", phone: "+91 80 2680 2680", beds: "Low" },
    { name: "Motherhood Hospital, Indiranagar", location: { lat: 12.9723, lng: 77.6409 }, capabilities: ["Maternity"], address: "324, Chinmaya Mission Hospital Rd, Indiranagar, Bengaluru", phone: "+91 80 6723 8833", beds: "Medium" },
    { name: "Suguna Hospital", location: { lat: 12.9976, lng: 77.5621 }, capabilities: ["Basic", "BLS", "ALS"], address: "1A/87, Dr Rajkumar Rd, Rajajinagar, Bengaluru", phone: "+91 80 4019 4444", beds: "High" },
    { name: "Manipal Hospital, Yeshwanthpur", location: { lat: 13.0249, lng: 77.5519 }, capabilities: ["Basic", "BLS", "ALS"], address: "26/4, Brigade Gateway, beside Metro, Malleshwaram, Bengaluru", phone: "+91 1800 102 4647", beds: "Medium"},
    { name: "PES University Hospital", location: { lat: 12.9324, lng: 77.5329 }, capabilities: ["Basic", "BLS", "ALS", "ICU"], address: "Outer Ring Rd, Banashankari 3rd Stage, Bengaluru", phone: "+91 80 2672 1981", beds: "Low" },
    { name: "Aster CMI Hospital, Hebbal", location: { lat: 13.0475, lng: 77.6069 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "No. 43/2, New Airport Road, NH 44, Sahakar Nagar, Hebbal, Bengaluru", phone: "+91 80 4342 0100", beds: "High" },
    { name: "Sakra World Hospital, Marathahalli", location: { lat: 12.9317, lng: 77.7001 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "SY NO 52/2 & 52/3, Devarabeesanahalli, Marathahalli - Sarjapur Outer Ring Rd, Bengaluru", phone: "+91 80 4969 4969", beds: "High" },
    { name: "Apollo Hospitals, Bannerghatta Road", location: { lat: 12.8933, lng: 77.5976 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "154/11, Bannerghatta Road, Amalodbhavi Nagar, Panduranga Nagar, Bengaluru", phone: "+91 80 2630 4050", beds: "High" },
    { name: "Cloudnine Hospital, Old Airport Road", location: { lat: 12.9591, lng: 77.6534 }, capabilities: ["Maternity", "Pediatrics", "Neonatal ICU"], address: "115, HAL Airport road, Opp. Kemp Fort Mall, Bengaluru", phone: "+91 99728 99728", beds: "Medium" },
    { name: "Sri Jayadeva Institute of Cardiovascular Sciences and Research, Jayanagar", location: { lat: 12.9192, lng: 77.5873 }, capabilities: ["Specialized Cardiac Care (Basic, BLS, ALS, ICU, Cardiac Surgery)"], address: "Bannerghatta Main Rd, Jayanagar 9th Block, Bengaluru", phone: "+91 80 2297 7400", beds: "High" },
    { name: "St. John's Medical College Hospital, Koramangala", location: { lat: 12.9355, lng: 77.6230 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "Sarjapur Rd, John Nagar, Koramangala, Bengaluru", phone: "+91 80 2206 5000", beds: "High" },
    { name: "Hosmat Hospital, Magrath Road", location: { lat: 12.9669, lng: 77.6074 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Specialized in Orthopedics and Trauma Care"], address: "45, Magrath Rd, Ashok Nagar, Bengaluru", phone: "+91 80 4122 2222", beds: "Medium" },
    { name: "Sagar Hospitals, Jayanagar", location: { lat: 12.9299, lng: 77.5707 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "Shavige Malleshwara Hills, 44/54, 30th Cross Rd, Tilak Nagar, Jayanagar, Bengaluru", phone: "+91 80 4288 8888", beds: "High" },
    { name: "Bangalore Baptist Hospital, Hebbal", location: { lat: 13.0373, lng: 77.5925 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster"], address: "Bellary Rd, Vinayakanagar, Hebbal, Bengaluru", phone: "+91 80 2202 4700", beds: "Medium" },
    { name: "Vydehi Institute of Medical Sciences and Research Centre, Whitefield", location: { lat: 12.9778, lng: 77.7314 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "82, Nallurahalli Main Rd, near BMTC 18th Depot, Whitefield, Bengaluru", phone: "+91 80 2841 3381", beds: "High" },
    { name: "M. S. Ramaiah Memorial Hospital, Mathikere", location: { lat: 13.0354, lng: 77.5648 }, capabilities: ["Basic", "BLS", "ALS", "ICU", "Maternity", "Disaster", "Multi-Speciality"], address: "MSR Nagar, MSRIT Post, New BEL Rd, Bengaluru", phone: "+91 80 4050 2000", beds: "High" }
];


// Using a separate export for initial incidents as it might not be needed in the same way
export const initialIncidents: Incident[] = [];

    

    
