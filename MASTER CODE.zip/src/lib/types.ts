
export type IncidentStatus = 'New' | 'In Progress' | 'Resolved';
export type ResponderStatus = 'Available' | 'Enroute to Incident' | 'On Scene' | 'At Scene - Deciding Hospital' | 'Enroute to Hospital' | 'At Hospital' | 'Returning to Base' | 'Awaiting Report';
export type HospitalBedStatus = 'High' | 'Medium' | 'Low';
export type HospitalCapability = 'Basic' | 'BLS' | 'ALS' | 'ICU' | 'Maternity' | 'Disaster' | 'Multi-Speciality' | 'Pediatrics' | 'Neonatal ICU' | 'Specialized Cardiac Care (Basic, BLS, ALS, ICU, Cardiac Surgery)' | 'Specialized in Orthopedics and Trauma Care';

export interface Location {
  lat: number;
  lng: number;
}

export interface Incident {
  id: string;
  type: string;
  location: Location;
  status: IncidentStatus;
  timestamp: string;
  description: string;
  report: string;
  unitId?: string;
}

export interface Responder {
  id: string;
  type: string;
  lat: number;
  lng: number;
  status: ResponderStatus;
  incidentId: string | null;
  baseLocation: Location;
  routeIndex?: number;
}

export interface Hospital {
  name: string;
  location: Location;
  capabilities: HospitalCapability[];
  address: string;
  phone: string;
  beds: HospitalBedStatus;
}

export interface IncidentType {
    name: string;
    type: 'Medical' | 'Fire' | 'Crime' | 'Disaster';
    recommendedUnit: string;
    description: string;
    severity: string;
    hospitalCapability: HospitalCapability;
    requiresPackage: boolean;
}

export interface FleetDescription {
    name: string;
    purpose: string;
    staff: string;
    equipment: string;
    imageKey: string;
}

export interface LogEntry {
  timestamp: Date;
  message: string;
  level: 'info' | 'success' | 'error' | 'dispatch' | 'ai';
  incidentId?: string;
}
